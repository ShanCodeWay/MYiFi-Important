// ignore_for_file: file_names

import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:flutter/material.dart';

import '../../widgets/CommonAlert.dart';
import '../HomeScreen/HomeScreen.dart';
import '../MenuScreen/MenuScreen.dart';
import '../ProfileScreen/ProfileScreen.dart';

class DashboardScreen extends StatefulWidget {
  // const DashboardScreen({super.key});
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }




  void _backPress() {
    if (_currentIndex == 0) {
      showAlertDialog(context, 'Do you want to Logout ?',
          title: 'Logout', isPositiveBtnVisible: true, onPressPositiveBtn: () {
        Navigator.of(context).pop(); // Close the AlertDialog
        Navigator.of(context).pop(); // Navifate to Login
      });
    } else {
      _onItemTapped(0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (bool didPop) {
        if (didPop) {
          return;
        }
        _backPress();
      },
      child: Scaffold(
        appBar: _currentIndex == 0
            ? null
            : _currentIndex == 1
                ? AppBar(
                    title: Text(
                      'Menu',
                      style: TextStyle(
                          color: AppColors.WHITE,
                          fontSize: Styles.FONT_SIZE_20),
                    ),
                    leading: IconButton(
                      onPressed: () => _backPress(),
                      icon: Icon(
                        Icons.navigate_before_sharp,
                        size: 30,
                        color: AppColors.WHITE,
                      ),
                    ),
                    backgroundColor: AppColors.PRIMARY_BLUE,
                  )
                : _currentIndex == 2
                    ? AppBar(
                        title: Text(
                          'Profile',
                          style: TextStyle(
                              color: AppColors.WHITE,
                              fontSize: Styles.FONT_SIZE_20),
                        ),
                        leading: IconButton(
                          onPressed: () => _backPress(),
                          icon: Icon(
                            Icons.navigate_before_sharp,
                            size: 30,
                            color: AppColors.WHITE,
                          ),
                        ),
                        backgroundColor: AppColors.PRIMARY_BLUE,
                      )
                    : AppBar(),
        body: IndexedStack(
          index: _currentIndex,
          children: [
            HomeScreen(),
            MenuScreen(),
            ProfileScreen(),
          ],
        ),

        //  Navigator(
        //   key: homePageKey,
        //   onGenerateRoute: (RouteSettings settings) {
        //     final args = settings.arguments;
        //     switch (settings.name) {
        //       case '/home':
        //         return MaterialPageRoute(
        //             builder: (_) => HomeScreen(key: homePageKey));
        //       case '/search':
        //         return MaterialPageRoute(
        //             builder: (_) => HomeScreen(key: searchPageKey));
        //       case '/profile':
        //         return MaterialPageRoute(
        //             builder: (_) => HomeScreen(key: profilePageKey));
        //       default:
        //         return MaterialPageRoute(
        //             builder: (_) => HomeScreen(key: homePageKey));
        //     }
        //   },
        // ),

        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          selectedItemColor: AppColors.PRIMARY_BLUE,
          unselectedItemColor: AppColors.PRIMARY_GREY,
          selectedLabelStyle: TextStyle(fontWeight: Styles.MEDIUM),
          onTap: _onItemTapped,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(
                Icons.home_rounded,
              ),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.line_style_rounded),
              label: 'Menu',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
