import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/MenuScreen/InvoiceScreen/InvoiceScreen.dart';
import 'package:destinity_member_dev/views/MenuScreen/Reservations/Reservations.dart';
import 'package:destinity_member_dev/views/MenuScreen/StatementsScreen/StatementsScreen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../configs/CommonFunctions.dart';
import '../../widgets/CommonAlert.dart';
import 'EmptyScreen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  static List<Map<String, dynamic>> lstMenuCategories = [
    {
      "MenuCode": "M01",
      "MenuName": "Invoice Details",
      "MenuType": 1,
      "MenuIcon": '',
      "isActive": true,
    },
    {
      "MenuCode": "M07",
      "MenuName": "Statements",
      "MenuType": 1,
      "MenuIcon": '',
      "isActive": true,
    },
    {
      "MenuCode": "M02",
      "MenuName": "F&B Pickup Order",
      "MenuType": 3,
      "MenuIcon": '',
      "isActive": false,
    },
    {
      "MenuCode": "M03",
      "MenuName": "Sport Reservations",
      "MenuType": 2,
      "MenuIcon": '',
      "isActive": true,
    },
    {
      "MenuCode": "M04",
      "MenuName": "Event Reservations",
      "MenuType": 2,
      "MenuIcon": '',
      "isActive": false,
    },
    {
      "MenuCode": "M05",
      "MenuName": "New Dine-in",
      "MenuType": 4,
      "MenuIcon": '',
      "isActive": false,
    },
    {
      "MenuCode": "M06",
      "MenuName": "My Subscription",
      "MenuType": 1,
      "MenuIcon": '',
      "isActive": false,
    },

  ];
  backPress() {
        
    showAlertDialog(context, 'Do you want to Logout ?',
        title: 'Logout', isPositiveBtnVisible: true, onPressPositiveBtn: () {
      Navigator.of(context).pop(); // Close the AlertDialog
      Navigator.of(context).pop(); // Navifate to Login
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: SafeArea(
          child: SingleChildScrollView(
            child: GridView.builder(
              padding: EdgeInsets.all(20),
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: getCrossAxisCount(context),
                  crossAxisSpacing: 20.0,
                  mainAxisSpacing: 20.0,
                  // mainAxisExtent: 150,
                ),
                itemCount: lstMenuCategories.length,
                itemBuilder: (_, index) {
                  return MenuCategory(lstMenuCategories[index]);
                }),
          ),
        ),
      ),
    );
  }

  Widget MenuCategory(objMenuCategory) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => objMenuCategory['MenuCode'] == 'M01'
                  ? InvoiceScreen()
                  : objMenuCategory['MenuCode'] == 'M07'
                      ? StatementsScreen()
                      : objMenuCategory['MenuCode'] == 'M03'
                          ? Reservations()
                          : EmptyScreen()),
        );
      },
      child: Container(
      
    
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            color: objMenuCategory['isActive'] == true
                ? AppColors.WHITE
                : AppColors.WHITE,
            borderRadius: BorderRadius.circular(20),
            boxShadow: objMenuCategory['isActive'] == true
                ? [
                    BoxShadow(
                      color: AppColors.PRIMARY_BLUE,
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: const Offset(0, 0),
                    )
                  ]
                : [
                    BoxShadow(
                      color: AppColors.PRIMARY_GREY_LARK,
                      spreadRadius: 0.3,
                      blurRadius: 5,
                      offset: const Offset(1, 1), // changes position of shadow
                    )
                  ]),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //Dinuranga - implement SVG image when changing the no of order types
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: objMenuCategory['MenuType'] == 1
                    ? AppColors.PRIMARY_BLUE
                    : objMenuCategory['MenuType'] == 2
                        ? AppColors.PRIMARY_GREEN
                        : objMenuCategory['MenuType'] == 3
                            ? AppColors.PRIMARY_RED
                            : AppColors.PRIMARY_YELLOW,
              ),
              child: Center(
                child: SvgPicture.asset(
                  'assets/icons/MenuCategory/${objMenuCategory['MenuCode']}.svg',
                  fit: BoxFit.contain,
                  height: 30,
                  width: 30,
                ),
              ),
            ),
            Styles.sizebox20,
            Text(objMenuCategory['MenuName'],
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: AppColors.PRIMARY_BLACK,
                  fontSize: Styles.FONT_SIZE_12,
                  fontFamily: 'Poppins',
                  fontWeight: Styles.MEDIUM,
                )),
            Styles.sizebox10,
          ],
        ),
      ),
    );
  }
}
