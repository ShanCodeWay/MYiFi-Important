import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:flutter/cupertino.dart';

class EmptyScreen extends StatefulWidget {
  const EmptyScreen({super.key});

  @override
  State<EmptyScreen> createState() => _EmptyScreenState();
}

class _EmptyScreenState extends State<EmptyScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Loading', []),
      body: SafeArea(
          child: Center(
        child: Styles.circularProgressIOS,
      )),
    );
  }
}
