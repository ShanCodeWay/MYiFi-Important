import '../../../configs/common_Exports.dart';

class InvoiceScreenStyles {
  static TextStyle TextStyle_Empty = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_BLUE,
      fontSize: Styles.FONT_SIZE_16);
  static BoxDecoration BoxDecorationSingleInvoice = BoxDecoration(
      color: AppColors.WHITE,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(
          color: AppColors.PRIMARY_BLACK.withOpacity(0.2), width: 1));

  static BoxDecoration BoxDecorationSingleInvoice_Leading = BoxDecoration(
    gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          AppColors.PRIMARY_GREEN,
          AppColors.PRIMARY_GREEN.withOpacity(0.8),
        ]),
    borderRadius: BorderRadius.circular(10),
  );

  static TextStyle TextStyle_InvoiceNo = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.SEMI_BOLD,
      color: AppColors.WHITE,
      fontSize: Styles.FONT_SIZE_14);

  static TextStyle TextStyle_InvoiceTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_14);
  static TextStyle TextStyle_selectDate = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_12);
  static TextStyle TextStyle_InvoiceBill = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      color: AppColors.PRIMARY_BLUE,
      fontSize: Styles.FONT_SIZE_14);
  static TextStyle TextStyle_InvoiceDate = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_GREY,
      fontSize: Styles.FONT_SIZE_10);
  static TextStyle TextStyle_FromTo = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.WHITE,
      fontSize: Styles.FONT_SIZE_12);
}
