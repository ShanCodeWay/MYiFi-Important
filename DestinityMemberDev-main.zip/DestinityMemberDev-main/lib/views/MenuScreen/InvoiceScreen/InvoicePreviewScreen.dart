import 'dart:ffi';

import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/MenuScreen/InvoiceScreen/InvoicePreviewScreenStyles.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/material.dart';

import '../../../widgets/CommonAppbar.dart';
import 'package:intl/intl.dart';

import 'InvoiceScreenStyles.dart';

class InvoicePreviewScreen extends StatefulWidget {
  final Map<String, dynamic> invoiceData;

  const InvoicePreviewScreen({required this.invoiceData, super.key});

  @override
  State<InvoicePreviewScreen> createState() => _InvoicePreviewScreenState();
}

class _InvoicePreviewScreenState extends State<InvoicePreviewScreen> {
  @override
  Widget build(BuildContext context) {
    String strGuestCode = 'H132';
    String strGuestName = 'Mr. B.J Hapugalla';
    String strCompanyName = 'MEMBER';
    String strAddress = '31/2, Welikada Road, Rajagiriya.5';
    String strVatNo = '409087450­7000';
    String ComRegNo = 'TH/118';
    String Tour = '4';
    String InvoiceNo = widget.invoiceData['InvoiceNo'];
    DateTime Date = widget.invoiceData['Date'];
    String GrcNo = '0005625';
    DateTime ArrivalDate = widget.invoiceData['Date'];
    DateTime DepatureDate = widget.invoiceData['Date'];
    int Pax = widget.invoiceData['InvoiceType'];
    double Bill = widget.invoiceData['Bill'];

    return Scaffold(
      appBar: CommonAppbar(context, 'Invoice Details', []),
      body: SafeArea(
          child: Container(
        width: double.infinity,
        height: double.infinity,
        padding:
            const EdgeInsets.only(bottom: 10, left: 30, right: 30, top: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    singleHeaderDetailRow(
                        Icons.person_outline_sharp, 'Guest Code', strGuestCode),
                    singleHeaderDetailRow(Icons.document_scanner_outlined,
                        'Guest Name', strGuestName),
                    singleHeaderDetailRow(Icons.maps_home_work_outlined,
                        'Company Name', strCompanyName),
                    singleHeaderDetailRow(
                        Icons.location_on_outlined, 'Address', strAddress),
                    singleHeaderDetailRow(
                        Icons.document_scanner_outlined, 'VAT No', strVatNo),
                    singleHeaderDetailRow(Icons.format_list_numbered_outlined,
                        'Com Reg.No', ComRegNo),
                    singleHeaderDetailRow(Icons.tour_outlined, 'Tour', Tour),
                    singleHeaderDetailRow(
                        Icons.inventory_outlined, 'Invoice No', InvoiceNo),
                    singleHeaderDetailRow(Icons.date_range_outlined, 'Date',
                        DateFormat('yyyy-MM-dd').format(Date)),
                    singleHeaderDetailRow(
                        Icons.inventory_2_outlined, 'GRC No', GrcNo),
                    singleHeaderDetailRow(
                        Icons.navigate_next_outlined,
                        'Arrival',
                        DateFormat('yyyy-MM-dd   HH:mm ').format(ArrivalDate)),
                    singleHeaderDetailRow(
                        Icons.navigate_before_outlined,
                        'Depature',
                        DateFormat('yyyy-MM-dd   HH:mm ').format(DepatureDate)),
                    singleHeaderDetailRow(Icons.contacts_outlined, 'Pax', Pax),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: CustomButton(
                  'View More',
                  btnIcon: Icons.list,
                  iconColor: AppColors.WHITE,
                  () => InvoicePreviewBottomSheet(context),
                  btnWidth: double.maxFinite),
            ),
          ],
        ),
      )),
    );
  }

  Widget singleHeaderDetailRow(IconData icon, title, value) {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Column(
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(
                  icon,
                  size: 22,
                  color: AppColors.PRIMARY_GREY,
                ),
                Text(
                  title,
                  style: InvoicePreviewScreenStyles.TextStyle_DetailTitle,
                ),
              ],
            ),
            Styles.sizebox05,
            Container(
                height: 40,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20),
                decoration: BoxDecoration(
                    border: Border.all(color: AppColors.PRIMARY_BLUE),
                    color: AppColors.GREY.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10)),
                child: Text(value.toString())),
            Styles.sizebox10,
          ],
        )

        // Row(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   crossAxisAlignment: CrossAxisAlignment.center,
        //   children: [
        //     Expanded(
        //         flex: 1,
        //         child: Row(
        //           mainAxisAlignment: MainAxisAlignment.start,
        //           children: [
        //             Icon(
        //               icon,
        //               color: AppColors.PRIMARY_GREY,
        //             ),
        //             Styles.sizebox10W,
        //             Text(
        //               '$title :',
        //               style: InvoicePreviewScreenStyles.TextStyle_DetailTitle,
        //             ),
        //           ],
        //         )),
        //     Styles.sizebox10W,
        //     Expanded(
        //         flex: 1,
        //         child: Text(
        //           '$value',
        //           style: InvoicePreviewScreenStyles.TextStyle_DetailValue,
        //         ))
        //   ],
        // ),

        );
  }

// Dinuranga - Bill Preview 13/03/2023
  InvoicePreviewBottomSheet(context) {
    //api call to get the final price including (tax + vat)
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
          height: MediaQuery.of(context).size.height * 0.9,
          decoration: BoxDecoration(
            color: AppColors.WHITE,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(25.0),
              topRight: Radius.circular(25.0),
            ),
          ),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(0.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 30.0, top: 15),
                        child: Text('Invoice Preview',
                            style: InvoicePreviewScreenStyles
                                .TextStyle_DetailValue),
                      ),
                      Padding(
                          padding: const EdgeInsets.only(top: 15.0, right: 25),
                          child: IconButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              icon: Icon(Icons.close_rounded)))
                    ],
                  ),
                  Expanded(
                    flex: 3,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: AppColors.WHITE,
                        borderRadius: Styles.borderRadius20,
                      ),
                      child: ListView(
                        padding: const EdgeInsets.only(
                            left: 0, top: 5, bottom: 10, right: 0),
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                flex: 2,
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'RefNo',
                                    style: InvoicePreviewScreenStyles
                                        .TextStyleBillTitleValue,
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Date',
                                    style: InvoicePreviewScreenStyles
                                        .TextStyleBillTitleValue,
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Room No',
                                    style: InvoicePreviewScreenStyles
                                        .TextStyleBillTitleValue,
                                  ),
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Value',
                                    style: InvoicePreviewScreenStyles
                                        .TextStyleBillTitleValue,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SingleInvoiceCard('13/04/2023', '(R34539) RESTAURANT',
                              'R34539', '027', '7,865.00'),
                          SingleInvoiceCard(
                              '15/04/2023',
                              '(C07814) Caddy Invoice',
                              'C07814',
                              '027',
                              '770.75'),
                          SingleInvoiceCard('15/04/2023', '(B05234) BAR',
                              'B05234 ', '027', '2,062.50'),
                          SingleInvoiceCard(
                              '13/04/2023 ',
                              '(R34539) RESTAURANT',
                              'R34495',
                              '027',
                              '1,845.00'),
                          SingleInvoiceCard(
                              '13/04/2023',
                              '(C07806) Caddy Invoice ',
                              'C07806',
                              '027',
                              '770.75'),
                        ],
                      ),
                    ),
                  ),

                  //sub total card starts
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(25.0),
                    decoration: BoxDecoration(
                      //   color: AppColors.PRIMARY_BLUE.withOpacity(0.1),
                      borderRadius: Styles.borderRadius20,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('Sub Amount',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '41,160.60',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('Service Charge',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '4,116.08',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('TDL',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '0.00',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('NBT',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '1,158.71',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('VAT',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '6,963.11',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text('Advance Payment',
                                style: InvoicePreviewScreenStyles
                                    .TextStyleOrderListPrice),
                            Text(
                              '0.00',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                          ],
                        ),
                        const Divider(
                          height: 50,
                          color: Colors.black,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              'Total',
                              style: InvoicePreviewScreenStyles
                                  .TextStyleOrderListPrice,
                            ),
                            Text(
                              'Rs. 53,398.50',
                              style: InvoicePreviewScreenStyles.TextStyleTotal,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )),
    );
  }

  //Single Event Card
  Widget SingleInvoiceCard(date, description, ref, roomNo, value) {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: Column(
        children: [
          ExpansionTile(
            backgroundColor: AppColors.TRANSPARENT,
            collapsedBackgroundColor: AppColors.TRANSPARENT,
            title: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Text(
                        ref,
                        style: InvoicePreviewScreenStyles.TextStyleFoodName,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Text(
                        date,
                        style: InvoicePreviewScreenStyles.TextStyleFoodName,
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          roomNo,
                          style: InvoicePreviewScreenStyles.TextStyleFoodName,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            leading: Transform.rotate(
                angle: 3.14 / 2, child: Icon(Icons.navigate_next_rounded)),
            trailing: Text(
              value,
              style: InvoicePreviewScreenStyles.TextStyle_DetailValue,
            ),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Styles.sizebox40W,
                  Text(
                    description,
                    style: InvoicePreviewScreenStyles.TextStyleOrderListPrice,
                  ),
                ],
              )
            ],
          ),
          Styles.devider,
        ],
      ),
    );
  }

  // Widget buildBill(PatientModel patient) => Container(
  //       margin: const EdgeInsets.only(left: 0, right: 0, top: 10, bottom: 10),
  //       decoration: styles.BoxDecorationGlass,
  //       child: ExpansionTile(
  //         title: Row(
  //           mainAxisAlignment: MainAxisAlignment.spaceAround,
  //           children: [
  //             const Expanded(
  //               flex: 1,
  //               child: SizedBox(),
  //             ),
  //             Icon(Icons.circle_rounded, color: AppColors.yellowlight),
  //             styles.sizebox10W,
  //             Text(
  //               SetCamelCase(patient.name),
  //               style: styles.TextStyleH4Dark,
  //             ),
  //             const Expanded(
  //               flex: 8,
  //               child: SizedBox(),
  //             ),
  //             Text(
  //               'Rs.  ${patient.lstPrescription[0]['Amount'].toString()}',
  //               style: styles.TextStyleH4DarkBold,
  //             ),
  //             const Expanded(
  //               flex: 1,
  //               child: SizedBox(),
  //             ),
  //           ],
  //         ),
  //         children: <Widget>[
  //           Padding(
  //             padding: const EdgeInsets.only(left: 20.0, right: 20),
  //             child: Column(
  //               children: [
  //                 styles.devider,
  //                 Row(
  //                   mainAxisAlignment: MainAxisAlignment.start,
  //                   children: [
  //                     Expanded(
  //                       flex: 2,
  //                       child: Text(
  //                         'Medicine',
  //                         style: styles.TextStyleH4Italic,
  //                       ),
  //                     ),
  //                     Expanded(
  //                       flex: 2,
  //                       child: Row(
  //                         mainAxisAlignment: MainAxisAlignment.spaceAround,
  //                         children: [
  //                           Expanded(
  //                             flex: 1,
  //                             child: Text(
  //                               'Frequency',
  //                               style: styles.TextStyleH4Italic,
  //                             ),
  //                           ),
  //                           Expanded(
  //                             flex: 1,
  //                             child: Text(
  //                               'tabs',
  //                               style: styles.TextStyleH4Italic,
  //                             ),
  //                           ),
  //                           Expanded(
  //                             flex: 1,
  //                             child: Text(
  //                               'Duration',
  //                               style: styles.TextStyleH4Italic,
  //                             ),
  //                           )
  //                         ],
  //                       ),
  //                     ),
  //                     Expanded(
  //                       flex: 1,
  //                       child: Row(
  //                         mainAxisAlignment: MainAxisAlignment.start,
  //                         children: [
  //                           Text(
  //                             'Tablet Count',
  //                             style: styles.TextStyleH4Italic,
  //                           ),
  //                         ],
  //                       ),
  //                     ),
  //                   ],
  //                 ),
  //                 styles.devider, //after this

  //                 ListView.builder(
  //                   shrinkWrap: true,
  //                   physics: BouncingScrollPhysics(),
  //                   scrollDirection: Axis.vertical,
  //                   itemCount: patient
  //                       .lstPrescription[0]['jsonListPrescription'].length,
  //                   itemBuilder: (BuildContext context, int index) {
  //                     //  var ObjPrescription = patient.lstPrescription[0]['jsonListPrescription'] as List<PrescriptionModel>;

  //                     var ObjPrescription = patient.lstPrescription[0]
  //                         ['jsonListPrescription'][index];

  //                     var SelectedDrugIndex = [].obs;

  //                     // var x = patient.lstPrescription[0]['jsonListPrescription']
  //                     //     as List<dynamic>;

  //                     // ctrAddPatient.lstPrescription[index];

  //                     return Obx(
  //                       () => InkWell(
  //                         onTap: () {
  //                           if (SelectedDrugIndex.contains(index)) {
  //                             SelectedDrugIndex.remove(index);
  //                           } else {
  //                             SelectedDrugIndex.add(index);
  //                           }
  //                         },
  //                         child: Container(
  //                           decoration: BoxDecoration(
  //                             color: SelectedDrugIndex.contains(index)
  //                                 ? AppColors.primary.withOpacity(0.3)
  //                                 : AppColors.tranparent,
  //                             borderRadius: BorderRadius.circular(5),
  //                           ),
  //                           child: Column(
  //                             children: [
  //                               styles.sizebox10,
  //                               Row(
  //                                 mainAxisAlignment: MainAxisAlignment.start,
  //                                 children: [
  //                                   Expanded(
  //                                     flex: 2,
  //                                     child: Padding(
  //                                       padding:
  //                                           const EdgeInsets.only(left: 20.0),
  //                                       child: Text(
  //                                         SetCamelCase(
  //                                             ObjPrescription['MedicineName']),
  //                                         style: styles.TextStyleH4Dark,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                   Expanded(
  //                                     flex: 2,
  //                                     child: Row(
  //                                       mainAxisAlignment:
  //                                           MainAxisAlignment.spaceAround,
  //                                       children: [
  //                                         Expanded(
  //                                           flex: 1,
  //                                           child: Text(
  //                                             ObjPrescription['Frequency'],
  //                                             style: styles.TextStyleH4Dark,
  //                                           ),
  //                                         ),
  //                                         Expanded(
  //                                           flex: 1,
  //                                           child: Text(
  //                                             ObjPrescription['TabCount']
  //                                                 .toString(),
  //                                             style: styles.TextStyleH4Dark,
  //                                           ),
  //                                         ),
  //                                         Expanded(
  //                                           flex: 1,
  //                                           child: Text(
  //                                             ObjPrescription['Duration']
  //                                                 .toString(),
  //                                             style: styles.TextStyleH4Dark,
  //                                           ),
  //                                         )
  //                                       ],
  //                                     ),
  //                                   ),
  //                                   Expanded(
  //                                       flex: 1,
  //                                       child: Row(
  //                                         mainAxisAlignment:
  //                                             MainAxisAlignment.start,
  //                                         children: [
  //                                           Text(
  //                                             ctrPendingOrders
  //                                                 .CalculateTotalTablet(
  //                                               ObjPrescription['Frequency'],
  //                                               ObjPrescription['TabCount'],
  //                                               ObjPrescription['Duration'],
  //                                               ObjPrescription[
  //                                                   'MedicineCategory'],
  //                                             ).toString(),
  //                                             style: styles.TextStyleH4Dark,
  //                                           ),
  //                                         ],
  //                                       )),
  //                                 ],
  //                               ),
  //                             ],
  //                           ),
  //                         ),
  //                       ),
  //                     );
  //                   },
  //                 ),
  //                 styles.sizebox20,
  //                 Row(
  //                   mainAxisAlignment: MainAxisAlignment.end,
  //                   children: [
  //                     CustomButton(
  //                       title: 'Done',
  //                       onPressed: () async => await ctrPendingOrders
  //                           .deleteDocument(patient.patientID),
  //                       btnIcon: Icons.done_all,
  //                     ),
  //                   ],
  //                 ),
  //                 styles.sizebox20,
  //               ],
  //             ),
  //           ),
  //         ],
  //       ),
  //     );
}
