import 'package:destinity_member_dev/views/MenuScreen/InvoiceScreen/InvoiceScreenStyles.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:lottie/lottie.dart';
import '../../../configs/common_Exports.dart';
import 'package:intl/intl.dart';

import 'InvoicePreviewScreen.dart';

class InvoiceScreen extends StatefulWidget {
  const InvoiceScreen({Key? key}) : super(key: key);

  @override
  _InvoiceScreenState createState() => _InvoiceScreenState();
}

class _InvoiceScreenState extends State<InvoiceScreen> {
  static List<Map<String, dynamic>> lstInvoices = [
    {
      "InvoiceNo": "A12724",
      "InvoiceType": 1,
      "Venue": "Caddy",
      "Date": DateTime.now().subtract(Duration(days: 1)),
      "Bill": 4300.00
    },
    {
      "InvoiceNo": "A12722",
      "InvoiceType": 2,
      "Venue": "Course Related Fees",
      "Date": DateTime.now().subtract(Duration(days: 3)),
      "Bill": 2200.00
    },
    {
      "InvoiceNo": "A12624",
      "InvoiceType": 3,
      "Venue": "Main Bill",
      "Date": DateTime.now().subtract(Duration(days: 1)),
      "Bill": 18350.00
    },
    {
      "InvoiceNo": "A12602",
      "InvoiceType": 3,
      "Venue": "Restaurant Bill",
      "Date": DateTime.now().subtract(Duration(days: 5)),
      "Bill": 7200.00
    },

  ];
  static List<Map<String, dynamic>> lstTempInvoices = [];
  DateTime fromDate = DateTime.now();
  DateTime toDate = DateTime.now();
  
  Future<void> _selectFromDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: fromDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != fromDate) {
      setState(() {
        fromDate = picked;
      });
    }
  }

  Future<void> _selectToDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: toDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != toDate) {
      setState(() {
        toDate = picked;
      });
    }
  }

  _CheckInvoices() {
    setState(() {
      lstTempInvoices.clear();
      lstTempInvoices = lstInvoices.where((invoice) {
        DateTime invoiceDate = invoice['Date'];
        return invoiceDate.isAfter(fromDate) && invoiceDate.isBefore(toDate);
      }).toList();
    });
  }

  @override
  void initState() {
    super.initState();
    // lstTempInvoices.addAll(lstInvoices);
    // _autoSlide();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Invoice Details', []),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
            
              alignment: Alignment.center,
  
              decoration: BoxDecoration(
                  color: AppColors.PRIMARY_BLUE,
                  borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'From',
                        style: InvoiceScreenStyles.TextStyle_FromTo,
                      ),
                      Styles.sizebox05,
                      CommonDatePicker(
                          context, fromDate, () => _selectFromDate(context))
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'To',
                        style: InvoiceScreenStyles.TextStyle_FromTo,
                      ),
                      Styles.sizebox05,
                      CommonDatePicker(
                          context, toDate, () => _selectToDate(context))
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                
                      Text(
                        '',
                        style: InvoiceScreenStyles.TextStyle_FromTo,
                      ),
                      Container(
                        height: 40,
                        width: 60,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.WHITE.withOpacity(0.8),
                     
                        ),
                      
                        child: IconButton(
                            onPressed: () => _CheckInvoices(),
                            icon: Icon(
                              Icons.search,
                              color: AppColors.PRIMARY_BLACK,
                            )),
                      ),
                    ],
                  )
                ],
              ),
            ),
            //    SingleChildScrollView(child: Column()),
            Styles.sizebox10,
            Expanded(
              child: Container(
                child: Visibility(
                  visible: lstTempInvoices.isNotEmpty,
                  replacement: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Lottie.asset(
                          fit: BoxFit.contain,
                          height: 200,
                          alignment: Alignment.center,
                          width: 200,
                          'assets/lotties/lottie_search.json'),
                      Text(
                        'Invoices Not Found !',
                        style: InvoiceScreenStyles.TextStyle_Empty,
                      )
                    ],
                  ),
                  child: ListView.builder(
                    itemCount: lstTempInvoices.length,
                    itemBuilder: (context, index) {
                      return SingleInvoiceCard(lstTempInvoices[index]);
                    },
                  ),
                ),
              ),
            ),
            Styles.sizebox10,
                  ],
        ),
      ),
    );
  }

  //Single Event Card
  Widget SingleInvoiceCard(Map<String, dynamic> event) {
    String invoiceDate = DateFormat('yyyy-MM-dd hh:mm a').format(event['Date']);
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => InvoicePreviewScreen(
                    invoiceData: event,
                  )),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        width: double.infinity,
        height: 80,
        decoration: InvoiceScreenStyles.BoxDecorationSingleInvoice,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 2,
              child: Container(
                height: double.maxFinite,
                alignment: Alignment.center,
                decoration:
                    InvoiceScreenStyles.BoxDecorationSingleInvoice_Leading,
                child: Text(
                  event['InvoiceNo'],
                  style: InvoiceScreenStyles.TextStyle_InvoiceNo,
                ),
              ),
            ),
            Expanded(
              flex: 4,
              child: Container(
                margin: EdgeInsets.only(left: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event['Venue'],
                      style: InvoiceScreenStyles.TextStyle_InvoiceTitle,
                    ),
                    Text(
                      invoiceDate,
                      style: InvoiceScreenStyles.TextStyle_InvoiceDate,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          event['Bill'].toString(),
                          style: InvoiceScreenStyles.TextStyle_InvoiceBill,
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                alignment: Alignment.bottomRight,
                padding: EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SvgPicture.asset(
                      event['InvoiceType'] == 1
                          ? 'assets/icons/icon_drinks.svg'
                          : event['InvoiceType'] == 2
                              ? 'assets/icons/icon_pool.svg'
                              : event['InvoiceType'] == 3
                                  ? 'assets/icons/icon_meat.svg'
                                  : 'assets/icons/MenuCategory/M01.svg',
                    ),
                    Icon(
                      Icons.navigate_next_rounded,
                      color: AppColors.PRIMARY_GREY,
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

Widget CommonDatePicker(context, DateTime date, Function() selectDate) {
  return Container(
    height: 40,
    padding: EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      color: AppColors.WHITE.withOpacity(0.7),
      borderRadius: BorderRadius.circular(10),

    ),


    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text(
          DateFormat('yyyy-MM-dd').format(date),
          style: InvoiceScreenStyles.TextStyle_selectDate,
        ),
        IconButton(
            onPressed: () => selectDate(),
            icon: Icon(Icons.calendar_month_sharp))
      ],
    ),
  );
}
