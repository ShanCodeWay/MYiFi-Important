import '../../../configs/common_Exports.dart';

class InvoicePreviewScreenStyles {
  static TextStyle TextStyle_DetailTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_GREY,
      fontSize: Styles.FONT_SIZE_12);
  static TextStyle TextStyle_DetailValue = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.SEMI_BOLD,
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_14);

  static TextStyle TextStyleOrderListPrice = TextStyle(
    color: AppColors.BLACK,
    fontSize: Styles.FONT_SIZE_12,
    fontFamily: 'Poppins',
    fontWeight: Styles.REGULAR,
  );
  static TextStyle TextStyleTotal = TextStyle(
    color: AppColors.BLACK,
    fontSize: Styles.FONT_SIZE_14,
    fontFamily: 'Poppins',
    fontWeight: Styles.SEMI_BOLD,
  );
  static TextStyle TextStyleFoodName = TextStyle(
    color: AppColors.PRIMARY_BLUE,
    fontSize: Styles.FONT_SIZE_10,
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w600,
  );
  static TextStyle TextStyleBillTitleValue = TextStyle(
    color: AppColors.PRIMARY_BLACK,
    fontSize: Styles.FONT_SIZE_10,
    fontFamily: 'Poppins',
    fontWeight: Styles.MEDIUM,
  );
}
