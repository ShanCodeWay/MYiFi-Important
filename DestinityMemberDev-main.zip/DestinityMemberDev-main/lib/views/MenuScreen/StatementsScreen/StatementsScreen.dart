import 'dart:math';

import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/MenuScreen/StatementsScreen/StatementsScreenStyles.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_svg/svg.dart';

import '../../../widgets/CommonAlert.dart';
import '../../../widgets/CommonLoading.dart';

class StatementsScreen extends StatefulWidget {
  const StatementsScreen({super.key});

  @override
  State<StatementsScreen> createState() => _StatementsScreenState();
}

class _StatementsScreenState extends State<StatementsScreen> {
  var monthType = 'null';
  var isLoaded = false;
  var openBalance = '0.00';
  var closeBalance = '0.00';

  String generateRandomDoubleAsString(double min, double max) {
    final Random random = Random();
    double result = min + random.nextDouble() * (max - min);
    String formattedResult = result.toStringAsFixed(2);
    return _addCommasToNumber(formattedResult);
  }

  String _addCommasToNumber(String number) {
    List<String> parts = number.split('.');
    parts[0] = parts[0].replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match match) => '${match[1]},',
    );
    return parts.join('.');
  }

  void onPressGenerate(context) {
    if (monthType == 'null') {
      showAlertDialog(context, 'Please Select Month', title: 'Select Month');
    } else {
      showLoading(context, 'Loading..');
      Future.delayed(Duration(seconds: 2), () {
        hideLoading(context);
        setState(() {
          isLoaded = true;
          openBalance = generateRandomDoubleAsString(1500.00, 43000.45);
          closeBalance = generateRandomDoubleAsString(12000.00, 220000.45);
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Statements', []),
      body: SafeArea(
          child: Column(
        children: [
          Container(
            width: double.infinity,
            alignment: Alignment.center,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
                color: AppColors.PRIMARY_BLUE,
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(20),
                    bottomRight: Radius.circular(20))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                  
                  Text(
                    'Statement Month',
                    style: StatementsScreenStyles.TextStyleSatatementMonthText,
                  )
                ]),
                Styles.sizebox10,
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropDownStatementMonth(),
                    Styles.sizebox10W,
                    CustomButton('Generate',
                        btnColor: AppColors.WHITE,
                        fontColor: AppColors.PRIMARY_BLUE,
                        btnWidth: 150,
                        btnIcon: Icons.list,
                        iconColor: AppColors.PRIMARY_BLUE,
                        fontSize: Styles.FONT_SIZE_14, () {
                      onPressGenerate(context);
                    })
                  ],
                ),
              ],
            ),
          ),
          Styles.sizebox20,
          Visibility(
            visible: isLoaded,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: AppColors.PRIMARY_BLUE.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.PRIMARY_BLUE)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.attach_money,
                            color: AppColors.PRIMARY_GREY,
                            size: 20,
                          ),
                          Text(
                            'Opening Balance',
                            style: StatementsScreenStyles.TextStyleBalance,
                          ),
                        ],
                      ),
                      Styles.sizebox10,
                      Text(
                        'Rs.${openBalance.toString()}',
                        style: StatementsScreenStyles.TextStyleBalanceValue,
                      )
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: AppColors.PRIMARY_BLUE.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.PRIMARY_BLUE)),
                  alignment: Alignment.center,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.money_off_csred_outlined,
                            color: AppColors.PRIMARY_GREY,
                            size: 20,
                          ),
                          Text(
                            'Closing Balance',
                            style: StatementsScreenStyles.TextStyleBalance,
                          ),
                        ],
                      ),
                      Styles.sizebox10,
                      Text(
                        'Rs.${closeBalance.toString()}',
                        style: StatementsScreenStyles.TextStyleBalanceValue,
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          Styles.sizebox30,
          Visibility(
            visible: isLoaded,
            child: Container(
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.symmetric(horizontal: 10),
        
              decoration: BoxDecoration(
                  color: AppColors.PRIMARY_BLUE.withOpacity(0.4),
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(width: 80, child: Text('TXN Date')),
                  Styles.sizebox10W,
                  const Expanded(
                      flex: 3,
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Transaction'))),
                  SizedBox(
                    width: 60,
                    child: Row(
                      children: [
                        Transform.rotate(
                            angle: 0,
                            child: Icon(
                              Icons.upload_sharp,
                              color: AppColors.PRIMARY_RED,
                              size: 15,
                            )),
                        Text('Debit'),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 60,
                    child: Row(
                      children: [
                        Icon(
                          Icons.download,
                          color: AppColors.PRIMARY_GREEN,
                          size: 15,
                        ),
                        Text('Credit'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
              child: Visibility(
            visible: isLoaded,
            replacement: Center(
                child: Text(
              textAlign: TextAlign.center,
              'Statements Not Found ! \nSelect Month',
              style: StatementsScreenStyles.TextStyleSatatementMonth,
            )),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SingleDetailsRow('2023-10-01', 'Invoice F&B 0006',
                      generateRandomDoubleAsString(1500.00, 43000.45), '0.00'),
                  SingleDetailsRow('2023-10-03', 'Staff X mas fund 2023',
                      generateRandomDoubleAsString(200.00, 1500.45), '0.00'),
                  SingleDetailsRow('2023-10-12', 'SLUG Subscription 2024',
                      generateRandomDoubleAsString(200.00, 5000.45), '37.00'),
                  SingleDetailsRow('2023-10-17', 'Subs for member',
                      generateRandomDoubleAsString(200.00, 500.45), '0.00'),
                  SingleDetailsRow('2023-10-19', 'Invoice F&B 0006',
                      generateRandomDoubleAsString(12000.00, 67000.45), '0.00'),
                ],
              ),
            ),
          )),
          Styles.sizebox20
        ],
      )),
    );
  }

  Widget DropDownStatementMonth() {
    return Container(
      padding: const EdgeInsets.only(top: 0, bottom: 0, left: 15, right: 15),
      decoration: BoxDecoration(
          color: AppColors.WHITE.withOpacity(0.6),
          borderRadius: Styles.borderRadius10),
      child: DropdownButton<String>(
        value: monthType,
        underline: SizedBox(),
        onChanged: (String? newValue) {
          setState(() {
            monthType = newValue!;
          });
        },
        items: <DropdownMenuItem<String>>[
          DropdownMenuItem<String>(
            value: 'null',
            child: Text('Select Month',
                style: StatementsScreenStyles.TextStyleSatatementSelectMonth),
          ),
          DropdownMenuItem<String>(
            value: '2310',
            child: Text('Octomber 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2308',
            child: Text('August 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2307',
            child: Text('July 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2306',
            child: Text('June 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2305',
            child: Text('May 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2302',
            child: Text('Feb 2023',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
          DropdownMenuItem<String>(
            value: '2212',
            child: Text('December 2022',
                style: StatementsScreenStyles.TextStyleSatatementMonth),
          ),
        ],
      ),
    );
  }

  Widget SingleDetailsRow(date, transaction, debit, credit) {
    return Container(
      padding: EdgeInsets.all(10),
      margin: EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                  width: 80,
                  child: Text(
                    date,
                    style: StatementsScreenStyles.TextStyleVales,
                  )),
              Styles.sizebox10W,
              Expanded(
                  flex: 3,
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        transaction,
                        style: StatementsScreenStyles.TextStyleVales,
                      ))),
              Container(
                alignment: Alignment.center,
                width: 80,
                child: Text(
                  debit,
                  style: StatementsScreenStyles.TextStyleBalanceValue,
                ),
              ),
              Container(
                width: 50,
                alignment: Alignment.center,
                child: Text(
                  credit,
                  style: StatementsScreenStyles.TextStyleVales,
                ),
              ),
            ],
          ),
          Styles.devider,
        ],
      ),
    );
  }
}
