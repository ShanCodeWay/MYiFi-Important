import '../../../configs/common_Exports.dart';

class StatementsScreenStyles {
  static TextStyle TextStyleSatatementMonth = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.PRIMARY_BLACK,
      fontSize: 14,
      fontWeight: FontWeight.w500);
  static TextStyle TextStyleSatatementSelectMonth = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.PRIMARY_BLACK,
      fontSize: 14,
      fontStyle: FontStyle.italic,
      fontWeight: Styles.MEDIUM);
  static TextStyle TextStyleSatatementMonthText = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.WHITE,
      fontSize: Styles.FONT_SIZE_14,
      fontWeight: Styles.MEDIUM);
  static TextStyle TextStyleBalance = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.PRIMARY_BLACK.withOpacity(0.7),
      fontSize: Styles.FONT_SIZE_12,
      fontWeight: Styles.MEDIUM);
  static TextStyle TextStyleBalanceValue = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_12,
      fontWeight: Styles.MEDIUM);
  static TextStyle TextStyleVales = TextStyle(
      fontFamily: 'Poppins',
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_10,
      fontWeight: Styles.MEDIUM);
}
