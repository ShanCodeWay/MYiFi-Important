import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/MenuScreen/Reservations/AddReservation/AddReservationScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

import 'ReservationsStyles.dart';

class Reservations extends StatefulWidget {
  const Reservations({super.key});

  @override
  State<Reservations> createState() => _ReservationsState();
}

class _ReservationsState extends State<Reservations> {




  static List<Map<String, dynamic>> lstReservations = [
    {
      "ResNo": "R12724",
      "Status": 1,
      "Venue": "Bar & Restaurant",
      "Date": DateTime.now().add(Duration(days: 1)),
      "Duration": 3,
    },
    {
      "ResNo": "R12724",
      "Status": 1,
      "Venue": "Pool",
      "Date": DateTime.now().add(Duration(days: 3)),
      "Duration": 2.5,
    },
    {
      "ResNo": "R12724",
      "Status": 2,
      "Venue": "PlayGround",
      "Date": DateTime.now().add(Duration(days: 1)),
      "Duration": 4,
    },
    {
      "ResNo": "R12724",
      "Status": 3,
      "Venue": "Pool",
      "Date": DateTime.now().add(Duration(days: 5)),
      "Duration": 6,
    },
  ];


  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: CommonAppbar(context, 'Reservations', []),
      body: SafeArea(
          child: Container(
        width: double.infinity,
        height: double.infinity,
        child: Column(
          children: [
            Styles.sizebox10,
            Expanded(
              child: Container(
                child: Visibility(
                  visible: lstReservations.isNotEmpty,
                  replacement: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Lottie.asset(
                          fit: BoxFit.contain,
                          height: 200,
                          alignment: Alignment.center,
                          width: 200,
                          'assets/lotties/lottie_search.json'),
                      Text(
                        'Invoices Not Found !',
                        style: ReservationsStyles.TextStyle_Empty,
                      )
                    ],
                  ),
                  child: ListView.builder(
                    itemCount: lstReservations.length,
                    itemBuilder: (context, index) {
                      return SingleInvoiceCard(lstReservations[index]);
                    },
                  ),
                ),
              ),
            ),
            Styles.sizebox10,
          ],
        ),
      )),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.endFloat, // or endDocked
      floatingActionButton: FloatingActionButton(
          backgroundColor: AppColors.PRIMARY_BLUE,
          onPressed: () {


      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AddReservationScreen()),
        );

          },
          child: Icon(
            Icons.add,
            color: AppColors.WHITE,
          )),
    );
  }


  //Single Event Card
  Widget SingleInvoiceCard(Map<String, dynamic> event) {
    String invoiceDate = DateFormat('yyyy-MM-dd hh:mm a').format(event['Date']);

    String ResStatus;
    Color ResStatusColor;
    event['Status'] == 1
        ? {ResStatus = 'Confirmed', ResStatusColor = AppColors.PRIMARY_GREEN}
        : event['Status'] == 2
            ? {ResStatus = 'Pending', ResStatusColor = AppColors.PRIMARY_YELLOW}
            : {ResStatus = 'Confirmed', ResStatusColor = AppColors.PRIMARY_RED};

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      width: double.infinity,
      height: 80,
      decoration: ReservationsStyles.BoxDecorationSingleInvoice,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 2,
            child: Container(
              height: double.maxFinite,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      ResStatusColor,
                      ResStatusColor.withOpacity(0.8),
                    ]),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                ResStatus,
                style: ReservationsStyles.TextStyle_InvoiceNo,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              margin: EdgeInsets.only(left: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event['Venue'],
                    style: ReservationsStyles.TextStyle_InvoiceTitle,
                  ),
                  Text(
                    'Date: $invoiceDate',
                    style: ReservationsStyles.TextStyle_InvoiceBill,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        'Duration: ${event['Duration']} Hr',
                        style: ReservationsStyles.TextStyle_InvoiceDate,
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              alignment: Alignment.bottomRight,
              padding: EdgeInsets.all(10),
              child: Icon(
                Icons.navigate_next_rounded,
                color: AppColors.PRIMARY_GREY,
              ),
            ),
          )
        ],
      ),
    );
  }
}



 
