import '../../../../configs/common_Exports.dart';

class AddReservationScreenStyles {
  static TextStyle TextStyle_InputTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      fontSize: Styles.FONT_SIZE_16,
      color: AppColors.PRIMARY_BLACK);
  static TextStyle TextStyle_InputTitleDescription = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
          fontSize: Styles.FONT_SIZE_12,
      color: AppColors.PRIMARY_GREY);
}
