import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/widgets/CommonDropDown.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/material.dart';

import '../../../../widgets/CommonAlert.dart';
import '../../../../widgets/CommonLoading.dart';
import '../../../../widgets/InputField.dart';
import '../../InvoiceScreen/InvoiceScreen.dart';
import '../../InvoiceScreen/InvoiceScreenStyles.dart';
import 'AddReservationScreenStyles.dart';
import 'package:intl/intl.dart';

class AddReservationScreen extends StatefulWidget {
  const AddReservationScreen({super.key});

  @override
  State<AddReservationScreen> createState() => _AddReservationScreenState();
}

class _AddReservationScreenState extends State<AddReservationScreen> {
  static List<String> ActivityList = <String>[
    'PlayGround',
    'Swimming',
    'Tennis Court',
    'Bar & Restaurant'
  ];
  static List<String> TimeSlotsList = <String>[
    '12 PM  -  2 PM',
    '2 PM  -  4 PM',
    '4 PM  -  6 PM',
    '6 PM  -  8 PM'
  ];
  String dropdownValueActivity = ActivityList.first;
  String dropdownValueTime = TimeSlotsList.first;
  onChangeActivity(value) {
    setState(() {
      dropdownValueActivity = value;
    });
  }

  onChangeTimeSlot(value) {
    setState(() {
      dropdownValueTime = value;
    });
  }

  void _saveChanges(context) {
    showLoading(context, 'Requesting..');
    Future.delayed(Duration(seconds: 2), () {
      hideLoading(context);

      showAlertDialog(context, 'Reservation Requested',
          title: 'Sucessful', alertType: 2, onPressNegativeBtn: () {
        Navigator.of(context).pop();
        Navigator.of(context).pop();
      });
    });
  }

  Future<void> _selectDboDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: dboDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2200),
    );

    if (picked != null && picked != dboDate) {
      setState(() {
        dboDate = picked;
      });
    }
  }

  DateTime dboDate = DateTime.now();
  TextEditingController ctrRemark = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Add Reservation', []),
      body: SafeArea(
          child: Container(
        width: double.infinity,
        height: double.infinity,
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
                child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Activity',
                                style: AddReservationScreenStyles
                                    .TextStyle_InputTitle,
                              ),
                              Text(
                                ' *',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 17),
                              ),
                            ],
                          ),
                          Text(
                            'Select Your Activity from the list',
                            style: AddReservationScreenStyles
                                .TextStyle_InputTitleDescription,
                          ),
                        ],
                      ),
                    ],
                  ),
                  Styles.sizebox10,
                  CommonDropDown(
                    Icons.golf_course_outlined,
                    dropdownValueActivity,
                    ActivityList,
                    (value) => onChangeActivity(value),
                  ),
                  Styles.sizebox20,
                  Row(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Date',
                                style: AddReservationScreenStyles
                                    .TextStyle_InputTitle,
                              ),
                              Text(
                                ' *',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 17),
                              ),
                            ],
                          ),
                          Text(
                            'Add your Reservation date ',
                            style: AddReservationScreenStyles
                                .TextStyle_InputTitleDescription,
                          ),
                        ],
                      ),
                    ],
                  ),
                  Styles.sizebox10,
                  Container(
                      height: 50,
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.only(left: 10),
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.PRIMARY_BLUE),
                          color: AppColors.GREY.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(DateFormat('yyyy-MM-dd').format(dboDate)),
                          CommonDatePicker1(
                              context, dboDate, () => _selectDboDate(context)),
                        ],
                      )),
                  Styles.sizebox20,
                  Row(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Time Slots',
                                style: AddReservationScreenStyles
                                    .TextStyle_InputTitle,
                              ),
                              Text(
                                ' *',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 17),
                              ),
                            ],
                          ),
                          Text(
                            'Select Your preferred  time slot',
                            style: AddReservationScreenStyles
                                .TextStyle_InputTitleDescription,
                          ),
                        ],
                      ),
                    ],
                  ),
                  Styles.sizebox10,
                  CommonDropDown(
                    Icons.golf_course_outlined,
                    dropdownValueTime,
                    TimeSlotsList,
                    (value) => onChangeTimeSlot(value),
                  ),
                  Styles.sizebox20,
                  Row(
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Remarks',
                            style:
                                AddReservationScreenStyles.TextStyle_InputTitle,
                          ),
                          Text(
                            'Your special remark about the Reservation',
                            style: AddReservationScreenStyles
                                .TextStyle_InputTitleDescription,
                          ),
                        ],
                      ),
                    ],
                  ),
                  Styles.sizebox10,
                  CustomTextInputField('Add your Remark', ctrRemark,
                      height: 200.00, maxLines: 7),
                  Styles.sizebox20,
                ],
              ),
            )),
            Container(
              width: double.infinity,
              child: CustomButton('Confirm', () => _saveChanges(context)),
            )
          ],
        ),
      )),
    );
  }
}

Widget CommonDatePicker1(context, DateTime date, Function() selectDate) {
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      color: AppColors.PRIMARY_BLUE,
      borderRadius: BorderRadius.only(
          topRight: Radius.circular(10), bottomRight: Radius.circular(10)),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(
            onPressed: () => selectDate(),
            icon: Icon(
              Icons.calendar_month_sharp,
              color: AppColors.WHITE,
            ))
      ],
    ),
  );
}
