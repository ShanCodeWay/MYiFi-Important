import 'package:carousel_slider/carousel_slider.dart';
import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/HomeScreen/HomeScreenStyles.dart';
import 'package:destinity_member_dev/widgets/CommonAlert.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:badges/badges.dart' as badges;

import '../../styles/AppColors.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // static final List<String> imageUrls = [
  //   "https://marketplace.canva.com/EAE-CDHyYD8/1/0/1600w/canva-fast-food-modern-banner-landscape-jcB1bYM56VQ.jpg",
  //   "https://i.pinimg.com/736x/8e/e3/f3/8ee3f3d17c2e0f1aae870117adfdba32.jpg",
  //   "https://graphicsfamily.com/wp-content/uploads/edd/2020/11/Tasty-Food-Web-Banner-Design-scaled.jpg",
  //   "https://img.freepik.com/premium-vector/fresh-healthy-food-recipe-facebook-cover-design_605333-67.jpg",
  //   "https://i.pinimg.com/564x/98/5a/11/985a111cefafe61fdf5d4b5b9043c652.jpg",
  //   "https://i.pinimg.com/originals/df/7a/c2/df7ac24c6207e015a4e6f9ab533d0d57.jpg",
  //   "https://img.freepik.com/free-vector/gradient-indian-restaurant-webinar-template_23-2149440853.jpg?size=626&ext=jpg&ga=GA1.1.44546679.1699660800&semt=ais"
  // ];

  static final List<String> imagePaths = [
    "assets/images/banner1.png",
    "assets/images/banner2.png",
    "assets/images/banner3.png",
  ];
  


  static List<Map<String, dynamic>> lstEvents = [
    {
      "Title": "Match 1",
      "Description": "All Members allowed",
      "Venue": "Open Ground 1",
      "EventType": 1,
      "Time": DateTime.now(),
      "Duration": 120,
    },
    {
      "Title": "Cocktail Party",
      "Description": "All Members allowed",
      "Venue": "Natural Club",
      "EventType": 2,
      "Time": DateTime.now(),
      "Duration": 180,
    },
    {
      "Title": "Buffet",
      "Description": "All Members allowed",
      "Venue": "Open Kitchen",
      "EventType": 3,
      "Time": DateTime.now(),
      "Duration": 60,
    },
    {
      "Title": "Match 1",
      "Description": "All Members allowed",
      "Venue": "Open Ground 1",
      "EventType": 1,
      "Time": DateTime.now().add(Duration(days: 1, hours: 3)),
      "Duration": 120,
    },
    {
      "Title": "Cocktail Party",
      "Description": "All Members allowed",
      "Venue": "Natural Club",
      "EventType": 2,
      "Time": DateTime.now().add(Duration(days: 2, hours: 1)),
      "Duration": 180,
    },
    {
      "Title": "Buffet",
      "Description": "All Members allowed",
      "Venue": "Open Kitchen",
      "EventType": 3,
      "Time": DateTime.now().add(Duration(days: 2, hours: 1)),
      "Duration": 60,
    },
    {
      "Title": "DJ",
      "Description": "All Members allowed",
      "Venue": "Main Club",
      "EventType": 2,
      "Time": DateTime.now().add(Duration(days: 3, hours: 1)),
      "Duration": 120,
    },
    {
      "Title": "Match 1",
      "Description": "All Members allowed",
      "Venue": "Open Ground 1",
      "EventType": 1,
      "Time": DateTime.now().add(Duration(days: 5, hours: 1)),
      "Duration": 120,
    },
    {
      "Title": "Cocktail Party",
      "Description": "All Members allowed",
      "Venue": "Natural Club",
      "EventType": 2,
      "Time": DateTime.now().add(Duration(days: 5, hours: 3)),
      "Duration": 180,
    },
    {
      "Title": "Buffet",
      "Description": "All Members allowed",
      "Venue": "Open Kitchen",
      "EventType": 3,
      "Time": DateTime.now().add(Duration(days: 5, hours: 5)),
      "Duration": 60,
    },
    {
      "Title": "DJ",
      "Description": "All Members allowed",
      "Venue": "Main Club",
      "EventType": 2,
      "Time": DateTime.now().add(Duration(days: 5, hours: 8)),
      "Duration": 120,
    },
  ];

  static List<Map<String, dynamic>> lstTempEvents = [];
  var strGreeting = 'Good';

  int _currentIndex = 0;

  void OnSelectDate(DateTime selectedDate) {
    setState(() {
      lstTempEvents.clear();
      lstTempEvents = lstEvents
          .where((event) =>
              event["Time"].year == selectedDate.year &&
              event["Time"].month == selectedDate.month &&
              event["Time"].day == selectedDate.day)
          .toList();
    });
  }
  

  String getGreeting() {
    DateTime now = DateTime.now();
    int hour = now.hour;

    if (hour >= 6 && hour < 12) {
      return 'Good Morning';
    } else if (hour >= 12 && hour < 17) {
      return 'Good Afternoon';
    } else {
      return 'Good Evening';
    }
  }

  backPress() {
    showAlertDialog(context, 'Do you want to Logout ?',
        title: 'Logout', isPositiveBtnVisible: true, onPressPositiveBtn: () {
      Navigator.of(context).pop(); // Close the AlertDialog
      Navigator.of(context).pop(); // Navifate to Login
    });
  }


  @override
  void initState() {
    super.initState();
    OnSelectDate(DateTime.now());

    setState(() {
      strGreeting = getGreeting();
    });
    // _autoSlide();
  }

  // void _autoSlide() async {
  //   while (true) {
  //     await Future.delayed(Duration(seconds: 5));

  //     // setState(() {
  //     //   _currentIndex = (_currentIndex + 1) % imageUrls.length;
  //     // });
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: 
      
      
      AppBar(
        elevation: 0,
        backgroundColor: AppColors.WHITE,
        leadingWidth: double.infinity,
        toolbarHeight: 60,
        leading: Padding(
          padding: const EdgeInsets.only(
            top: 10,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              IconButton(
                onPressed: () => backPress(),
                icon: Icon(
                  Icons.navigate_before_sharp,
                  size: 30,
                  color: AppColors.PRIMARY_BLACK,
                ),
              ),
         
              Styles.sizebox10W,
              Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hello Prageeth !',
                    style: Styles.TextStyle_Topic,
                  ),
                  Text(
                    strGreeting,
                    style: HomeScreenStyles.TextStyle_Greeting,
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          badges.Badge(
            position: badges.BadgePosition.topEnd(
              top: 0,
              end: 2,
            ),
            badgeAnimation: const badges.BadgeAnimation.scale(
                animationDuration: Duration(milliseconds: 1000)),
            showBadge: true,
            ignorePointer: true,
            badgeContent: const Text(
              '5',
              style: TextStyle(
                  fontSize: 12,
                  color: Colors.white,
                  fontWeight: FontWeight.w600),
            ),
            badgeStyle: badges.BadgeStyle(
              shape: badges.BadgeShape.circle,
              badgeColor: AppColors.PRIMARY_RED,
              padding: const EdgeInsets.all(6),
              borderRadius: BorderRadius.circular(0),
              borderSide: const BorderSide(color: Colors.white, width: 1),
              elevation: 0,
            ),
            child: Padding(
                padding: const EdgeInsets.only(top: 5.0),
                child: InkWell(
                  onTap: () => null,
                  child: Container(
                    decoration: BoxDecoration(shape: BoxShape.circle),
                    padding: EdgeInsets.all(7),
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Image.asset('assets/images/img_ProfilePic.png')),
                  ),
                )

       
                ),
          ),
          Styles.sizebox10W
       
        ],
    
      ),
      
      
      
      body: SafeArea(
        child: CustomScrollView(
          shrinkWrap: false,
          slivers: <Widget>[
            SliverAppBar(
              automaticallyImplyLeading: false,
              backgroundColor: AppColors.WHITE,
              foregroundColor: AppColors.WHITE,
              pinned: false,
              snap: false,
    
              floating: false,
              expandedHeight: 160.0,
              excludeHeaderSemantics: false,
              flexibleSpace: FlexibleSpaceBar(
                background: Column(
                  children: [
                    Styles.sizebox05,
                    Container(
                      width: double.infinity,
                      height: 150,
                      padding: EdgeInsets.all(10),
                      color: AppColors.TRANSPARENT,
                      child: CarouselSlider(
                        options: CarouselOptions(
                          autoPlay: true,
                          autoPlayInterval: Duration(seconds: 5),
                          viewportFraction: 1,
                          enableInfiniteScroll: true,
                          initialPage: _currentIndex,
                        ),
                        items: imagePaths.map((url) {
                          return ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: Image.asset(
                              url,
                              width: double.infinity,
                            fit: BoxFit.cover,
                            
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    // Row(
                    //     mainAxisAlignment: MainAxisAlignment.center,
                    //     children: indicators(imagePaths.length, _currentIndex)),
                    Styles.sizebox05,
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        '   Event Calender',
                        style: Styles.TextStyle_Topic,
                      ),
                    ],
                  ),
                  //Table calender Using [ table_calendar: ^3.0.9 ]
                  // Likes 2477 - unverified uploader
                  //  Container(color: AppColors.WHITE, child: EventCalender()),

                  //Table calender Using [ syncfusion_flutter_calendar: ^23.2.5]
                  // Likes 1211 - verified publisher iconsyncfusion.com
                  Container(
                      color: AppColors.WHITE, child: SyncfusionEventCalender()),
               
               
                  SizedBox(
                    height: 350,
                    child: Visibility(
                      visible: lstTempEvents.isNotEmpty,
                      replacement: Column(
                        children: [
                          Lottie.asset(
                              fit: BoxFit.contain,
                              height: 200,
                              alignment: Alignment.center,
                              width: 200,
                              'assets/lotties/lottie_search.json'),
                          Text(
                            'Events Not Found !',
                            style: HomeScreenStyles.TextStyle_Greeting,
                          )
                        ],
                      ),
                      child: ListView.builder(
                        itemCount: lstTempEvents.length,
                        itemBuilder: (context, index) {
                          return SingleEventCard(lstTempEvents[index]);
                        },
                      ),
                    ),
                  )
             
             
                ]))
          ],
        ),
      ),
    );
  }

//Image slider indicators
  List<Widget> indicators(imagesLength, currentIndex) {
    return List<Widget>.generate(imagesLength, (index) {
      return Container(
        margin: EdgeInsets.all(2),
        width: 7,
        height: 7,
        decoration: BoxDecoration(
            color: currentIndex == index
                ? AppColors.PRIMARY_BLACK
                : AppColors.PRIMARY_GREY_LARK,
            shape: BoxShape.circle),
      );
    });
  }

//Event Calender
  Widget EventCalender() {
    return Container(
      width: double.infinity,
      height: 300,
      margin: EdgeInsets.all(20),
      decoration: HomeScreenStyles.BoxDecorationCalender,
      child: TableCalendar(
        rowHeight: 30,
        firstDay: DateTime.utc(2010, 3, 14),
        lastDay: DateTime.utc(2030, 3, 14),
        focusedDay: DateTime.now(),
        headerStyle: HeaderStyle(
            titleTextStyle: TextStyle(fontWeight: Styles.SEMI_BOLD)),
        daysOfWeekStyle: DaysOfWeekStyle(
            weekdayStyle: TextStyle(color: AppColors.PRIMARY_BLUE),
            weekendStyle: TextStyle(color: AppColors.PRIMARY_BLUE)),
        calendarStyle: CalendarStyle(
            isTodayHighlighted: true,
            todayDecoration: BoxDecoration(
                color: AppColors.PRIMARY_GREEN,
                borderRadius: BorderRadius.circular(5)),
            selectedTextStyle: TextStyle(color: AppColors.PRIMARY_YELLOW),
            weekendTextStyle: TextStyle(
                color: AppColors.PRIMARY_GREY, fontWeight: Styles.MEDIUM),
            defaultTextStyle: TextStyle(
                color: AppColors.PRIMARY_GREY, fontWeight: Styles.MEDIUM)),
      ),
    );
  }

//SyncfusionEventCalender
  Widget SyncfusionEventCalender() {
    return Container(
        width: double.infinity,
        height: 250,
        padding: EdgeInsets.all(5),
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: HomeScreenStyles.BoxDecorationCalender,
        child: SfCalendar(
          view: CalendarView.month,
          firstDayOfWeek: 1, // make first day as Monday
          monthViewSettings: MonthViewSettings(showAgenda: false),
          showTodayButton: true,

          onSelectionChanged: (CalendarSelectionDetails details) {
            DateTime date = details.date!;
            // CalendarResource resource = details.resource!;

            OnSelectDate(date);
          },

          headerStyle: CalendarHeaderStyle(
              textStyle: TextStyle(
                  color: AppColors.PRIMARY_BLACK,
                  fontWeight: Styles.MEDIUM,
                  fontSize: Styles.FONT_SIZE_16)),
          viewHeaderStyle: ViewHeaderStyle(
              
              dayTextStyle: TextStyle(
                  fontSize: Styles.FONT_SIZE_10,
                  fontWeight: Styles.MEDIUM,
                  color: AppColors.PRIMARY_BLUE),
              backgroundColor: AppColors.PRIMARY_GREY_LARK.withOpacity(0.5)),
          //======= to flexible working days and working hours
          // view: CalendarView.workWeek,
          // timeSlotViewSettings: const TimeSlotViewSettings(
          //     startHour: 9,
          //     endHour: 23,
          //     nonWorkingDays: <int>[DateTime.friday, DateTime.saturday])
        ));
  }

//Single Event Card
  Widget 
  SingleEventCard(Map<String, dynamic> event) {
    String EventTime = DateFormat('hh:mm a').format(event['Time']);
    return InkWell(
      onTap: () {
        _showEventDetails(context, event);
      },
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        width: double.infinity,
        height: 80,
        decoration: HomeScreenStyles.BoxDecorationSingleEvent,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 2,
              child: Container(
                decoration: HomeScreenStyles.BoxDecorationSingleEvent_Leading(
                    event['EventType']),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        EventTime,
                        style: HomeScreenStyles.TextStyle_EventTime,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.timer_outlined,
                            color: AppColors.WHITE,
                            size: 20,
                          ),
                          Text(
                            ' ${event['Duration']} min',
                            style: HomeScreenStyles.TextStyle_EventDuration,
                          ),
                        ],
                      )
                    ]),
              ),
            ),
            Expanded(
              flex: 4,
              child: Container(
                margin: EdgeInsets.only(left: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event['Title'],
                      style: HomeScreenStyles.TextStyle_EventTitle,
                    ),
                    Text(
                      event['Venue'],
                      style: HomeScreenStyles.TextStyle_EventVenue,
                    )
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 1,
              child: Container(
                child: Icon(
                  Icons.navigate_next_rounded,
                  color: AppColors.PRIMARY_GREY,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  // Function to show the popup
  void _showEventDetails(BuildContext context, Map<String, dynamic> event) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
            backgroundColor: AppColors.PRIMARY_GREEN,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.4,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                  color: AppColors.WHITE,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                          child: Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                'Event Details',
                                style: HomeScreenStyles.TextStyle_EventDetails,
                              ))),
                      IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: Icon(
                            Icons.close,
                            color: AppColors.PRIMARY_GREY,
                          ))
                    ],
                  ),
                  Styles.sizebox30,
                  Expanded(
                      child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Styles.sizebox10W,
                            Expanded(
                                flex: 1,
                                child: Text(
                                  'Member Name',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetail,
                                )),
                            Expanded(
                                flex: 1,
                                child: Text(
                                  ': H.T  Hemantha',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetailValue,
                                ))
                          ],
                        ),
                        Styles.devider,
                        Styles.sizebox20,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Styles.sizebox10W,
                            Expanded(
                                flex: 1,
                                child: Text(
                                  'Activity',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetail,
                                )),
                            Expanded(
                                flex: 1,
                                child: Text(
                                  ': ${event['Title']}',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetailValue,
                                ))
                          ],
                        ),
                        Styles.devider,
                        Styles.sizebox20,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Styles.sizebox10W,
                            Expanded(
                                flex: 1,
                                child: Text(
                                  'Time',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetail,
                                )),
                            Expanded(
                                flex: 1,
                                child: Text(
                                  ': ${DateFormat('HH:mm a').format(event['Time'])}',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetailValue,
                                ))
                          ],
                        ),
                        Styles.devider,
                        Styles.sizebox20,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Styles.sizebox10W,
                            Expanded(
                                flex: 1,
                                child: Text(
                                  'Duration',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetail,
                                )),
                            Expanded(
                                flex: 1,
                                child: Text(
                                  ': ${event['Duration'].toString()}',
                                  style: HomeScreenStyles
                                      .TextStyle_PopUpEventDetailValue,
                                ))
                          ],
                        ),
                      ],
                    ),
                  )),
                  Styles.sizebox20,
                  Row(
                    children: [
                      Expanded(
                          child:
                              CustomButton('Ok', () => Navigator.pop(context)))
                    ],
                  )
                ],
              ),
            ));
      },
    );
  }

}
