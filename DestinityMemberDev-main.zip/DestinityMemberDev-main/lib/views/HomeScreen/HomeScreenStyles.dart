import '../../configs/common_Exports.dart';

class HomeScreenStyles {
  static TextStyle TextStyle_Greeting = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_BLUE,
      fontSize: Styles.FONT_SIZE_14);
  static TextStyle TextStyle_EventTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      color: AppColors.BLACK,
      fontSize: Styles.FONT_SIZE_16);
  static TextStyle TextStyle_EventVenue = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_GREY,
      fontSize: Styles.FONT_SIZE_12);
        static TextStyle TextStyle_EventTime = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.SEMI_BOLD,
      color: AppColors.WHITE,
      fontSize: Styles.FONT_SIZE_14);
              static TextStyle TextStyle_EventDuration = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.WHITE,
      fontSize: Styles.FONT_SIZE_10);
  static TextStyle TextStyle_EventDetails = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.SEMI_BOLD,
      fontSize: Styles.FONT_SIZE_16);

  static TextStyle TextStyle_PopUpEventDetail = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      fontSize: Styles.FONT_SIZE_14);
  static TextStyle TextStyle_PopUpEventDetailValue = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.SEMI_BOLD,
      fontSize: Styles.FONT_SIZE_14);


  static BoxDecoration BoxDecorationCalender = BoxDecoration(
      color: AppColors.WHITE,
      borderRadius: BorderRadius.circular(10),
      boxShadow: [
        BoxShadow(
          color: AppColors.PRIMARY_GREY_LARK,
          offset: Offset(0.0, 3.0), // Offset of the shadow
          blurRadius: 5.0, // Blur radius
          spreadRadius: 2.0,
        )
      ]);

  static BoxDecoration BoxDecorationSingleEvent = BoxDecoration(
      color: AppColors.WHITE,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(
          color: AppColors.PRIMARY_BLACK.withOpacity(0.2), width: 1));

  static BoxDecoration BoxDecorationSingleEvent_Leading(int eventType) {
    return BoxDecoration(
      gradient: eventType == 1
          ? LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                  AppColors.PRIMARY_GREEN,
                  AppColors.PRIMARY_GREEN.withOpacity(0.8),
                ])
          : eventType == 2
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                      AppColors.PRIMARY_RED,
                      AppColors.PRIMARY_RED.withOpacity(0.7),
                      Colors.amber.withOpacity(0.3)
                    ])
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                      AppColors.PRIMARY_GREY,
                      AppColors.PRIMARY_GREY.withOpacity(0.7),
                      AppColors.PRIMARY_GREY.withOpacity(0.4),
                    ]),
      borderRadius: BorderRadius.circular(10),
    );
  }
}
