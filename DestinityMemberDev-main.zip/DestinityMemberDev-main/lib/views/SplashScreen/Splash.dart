import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/styles/CommonStyles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../LoginScreen/LoginScreen.dart';

class Splash extends StatelessWidget {
  const Splash({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    // wait 5 seconds before navigating
    Future.delayed(Duration(seconds: 5), () {
      // Navigate to the login screen
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) =>
              LoginScreen(), // Replace LoginScreen with the actual name of your login screen
        ),
      );
    });

    return Scaffold(
      body: SafeArea(
          child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/logo_ic_club.png',
              height: 250,
              width: 250,
            ),
            Styles.sizebox40,
            Styles.circularProgressIOS,
            Styles.sizebox40,
            Text(
              'Loading...',
              style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: Styles.FONT_SIZE_16,
                  fontWeight: Styles.REGULAR,
                  color: AppColors.PRIMARY_GREY),
            )
          ],
        ),
      )),
    );
  }
}
