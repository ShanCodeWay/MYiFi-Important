import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/ProfileScreen/UserDetailsScreen/UserDetailStyles.dart';
import 'package:destinity_member_dev/widgets/CommonLoading.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../widgets/CommonAlert.dart';
import '../../../widgets/InputField.dart';
import 'package:intl/intl.dart';

enum Gender { M, F }

class UserDetailsScreen extends StatefulWidget {
  const UserDetailsScreen({super.key});

  @override
  State<UserDetailsScreen> createState() => _UserDetailsScreenState();
}

class _UserDetailsScreenState extends State<UserDetailsScreen> {
  TextEditingController ctrMemberCode = TextEditingController();
  TextEditingController ctrFname = TextEditingController();
  TextEditingController ctrMname = TextEditingController();
  TextEditingController ctrLname = TextEditingController();
  TextEditingController ctrTelNo = TextEditingController();
  TextEditingController ctrMobNo = TextEditingController();
  TextEditingController ctrFaxNo = TextEditingController();
  TextEditingController ctrEmail = TextEditingController();
  TextEditingController ctrAddr1 = TextEditingController();
  TextEditingController ctrAddr2 = TextEditingController();
  TextEditingController ctrAddr3 = TextEditingController();

  FocusNode focusNodectrFname = FocusNode();
  FocusNode focusNodectrMname = FocusNode();
  FocusNode focusNodectrLname = FocusNode();
  FocusNode focusNodectrTelNo = FocusNode();
  FocusNode focusNodectrMobNo = FocusNode();
  FocusNode focusNodectrFaxNo = FocusNode();
  FocusNode focusNodectrEmail = FocusNode();
  FocusNode focusNodectrAddr1 = FocusNode();
  FocusNode focusNodectrAddr2 = FocusNode();
  FocusNode focusNodectrAddr3 = FocusNode();

  Gender? _gender = Gender.M;

  DateTime dboDate = DateTime.now();

  Future<void> _selectDboDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: dboDate,
      firstDate: DateTime(1900),
      lastDate: dboDate,
    );

    if (picked != null && picked != dboDate) {
      setState(() {
        dboDate = picked;
      });
    }
  }

  void _saveChanges(context) {
    showLoading(context, 'Saving Changes..');
    Future.delayed(Duration(seconds: 2), () {
      hideLoading(context);

      showAlertDialog(context, 'Sucessfully updated the Details',
          title: 'Sucessful', alertType: 2, onPressNegativeBtn: () {
        Navigator.of(context).pop();
        Navigator.of(context).pop();
      });
    });
  }

  @override
  void initState() {
    ctrMemberCode.text = '4592';
    ctrFname.text = 'P.B.';
    ctrMname.text = 'Prageeth';
    ctrLname.text = 'Hapugalle';
    ctrAddr1.text = '31/2, Welikada Road';
    ctrAddr2.text = 'Kotuwegoda';
    ctrAddr3.text = 'Rajagiriya.5';
    ctrTelNo.text = '0112345677';
    ctrFaxNo.text = '000001';
    ctrMobNo.text = '0777598780';
    ctrEmail.text = 'hapupbn@gmail.com';
    

    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    ctrMemberCode.dispose();
    ctrFname.dispose();
    ctrMname.dispose();
    ctrLname.dispose();
    ctrTelNo.dispose();
    ctrEmail.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'User Details', []),
      body: SafeArea(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Expanded(
          //   flex: 2,
          //   child: Container(
          //       width: 120,
          //       height: 120,
          //       margin: EdgeInsets.symmetric(vertical: 10),
          //       decoration: UserDetailStyles.boxDecorationProfileImg,
          //       child: ClipRRect(
          //         borderRadius: BorderRadius.circular(100),
          //         child: Image.network(
          //           'https://www.photocase.com/photos/5459304-portrait-of-smiling-businessman-confidence-photocase-stock-photo-large.jpeg',
          //           fit: BoxFit.cover,
          //         ),
          //       )),
          // ),
          Expanded(
            flex: 5,
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
              
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.card_membership_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Member Code',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,

                 
                        Container(
                            height: 50,
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.only(left: 10),
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: AppColors.PRIMARY_BLUE),
                                color: AppColors.GREY.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(ctrMemberCode.text)),
                        Styles.sizebox20,
                        
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.person_outline_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'First Name',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),

                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter First Name', ctrFname,
                            context: context,
                            CurrentFocusNod: focusNodectrFname,
                            NextFocusNode: focusNodectrMname),
                        Styles.sizebox20,
                     

                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.person_outline_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Middle Name',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),

                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Middle Name', ctrMname,
                            context: context,
                            CurrentFocusNod: focusNodectrMname,
                            NextFocusNode: focusNodectrLname),
                        Styles.sizebox20,
                 
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.person_outline_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Last Name',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Last Name', ctrLname,
                            context: context,
                            CurrentFocusNod: focusNodectrLname,
                            NextFocusNode: focusNodectrAddr1),
                        Styles.sizebox20,
                      ],
                    ),
                    Styles.sizebox10,
                    Styles.devider,
                    Styles.sizebox10,

                    //Section 2
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.image_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Profile Picture',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 20),
                          decoration: BoxDecoration(
                              color: AppColors.GREY.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Stack(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(100),
                                    child: Image.asset(
                                      'assets/images/img_ProfilePic.png',
                                      fit: BoxFit.cover,
                                      width: 120,
                                      height: 120,
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 0,
                                    right: 0,
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(100),
                                        child: IconButton.filled(
                                            onPressed: () {
                                              ShowImageselection();
                                            },
                                            icon: Icon(Icons.add))),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Styles.sizebox10,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.calendar_month_sharp,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Date of Birth',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Container(
                            height: 50,
                            alignment: Alignment.centerLeft,
                            padding: EdgeInsets.only(left: 10),
                            decoration: BoxDecoration(
                                border:
                                    Border.all(color: AppColors.PRIMARY_BLUE),
                                color: AppColors.GREY.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(DateFormat('yyyy-MM-dd').format(dboDate)),
                                CommonDatePicker(context, dboDate,
                                    () => _selectDboDate(context)),
                              ],
                            )),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Gender',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Radio<Gender>(
                              value: Gender.M,
                              groupValue: _gender,
                              onChanged: (Gender? value) {
                                setState(() {
                                  _gender = value;
                                });
                              },
                            ),
                            Text('Male'),
                            Radio<Gender>(
                              value: Gender.F,
                              groupValue: _gender,
                              onChanged: (Gender? value) {
                                setState(() {
                                  _gender = value;
                                });
                              },
                            ),
                            Text('Female')
                          ],
                        ),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Address Line 1',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Address line 1', ctrAddr1,
                            context: context,
                            CurrentFocusNod: focusNodectrAddr1,
                            NextFocusNode: focusNodectrAddr2),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Address Line 2',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Address line 2', ctrAddr2,
                            context: context,
                            CurrentFocusNod: focusNodectrAddr2,
                            NextFocusNode: focusNodectrAddr3),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Address Line 3',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Address line 3', ctrAddr3,
                            context: context,
                            CurrentFocusNod: focusNodectrAddr3,
                            NextFocusNode: focusNodectrTelNo),
                        Styles.sizebox20,
                      ],
                    ),
                    Styles.devider,
                    Styles.sizebox10,

                    //Section 3
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                      
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                          Text(
                              'Telephone',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Telephone Number', ctrTelNo,
                            context: context,
                            CurrentFocusNod: focusNodectrTelNo,
                            NextFocusNode: focusNodectrMobNo),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Mobile',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Mobile Number', ctrMobNo,
                            context: context,
                            CurrentFocusNod: focusNodectrMobNo,
                            NextFocusNode: focusNodectrFaxNo),
                        Styles.sizebox20,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.phone_in_talk_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Fax',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                
                   
                        CustomTextInputField(
                            'Enter Fax Number', ctrFaxNo,
                            context: context,
                            CurrentFocusNod: focusNodectrFaxNo,
                            NextFocusNode: focusNodectrEmail),
                        Styles.sizebox20,



                   
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.email_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'Email',
                              style: UserDetailStyles.TextStyle_InputTitle,
                            ),

                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Your Email', ctrEmail,
                            context: context,
                            CurrentFocusNod: focusNodectrEmail),
                        Styles.sizebox20,
                      ],
                    ),
              
              
                  ],
                ),
              ),
            ),
          ),
        
        
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(bottom: 20, left: 20, right: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                    child: CustomButton(
                        fontSize: 14,
                        'Save changes',
                        () => _saveChanges(context))),
                Styles.sizebox10W,
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: Colors.blue),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel'),
                )
              ],
            ),
          )
       
       
        ],
      )),
    );
  }
  Widget CommonDatePicker(context, DateTime date, Function() selectDate) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: AppColors.PRIMARY_BLUE,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
              onPressed: () => selectDate(),
              icon: Icon(
                Icons.calendar_month_sharp,
                color: AppColors.WHITE.withOpacity(0.9),
              ))
        ],
      ),
    );
  }

  Future<void> ShowImageselection() async {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
          title: Text('Profile Picture'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Select Profile Picture'),
                Styles.sizebox20,
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                        flex: 1,
                        child: Container(
                          decoration: BoxDecoration(
                              color: AppColors.GREY.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(5)),
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.camera_outlined,
                                color: AppColors.PRIMARY_BLACK,
                              ),
                              Styles.sizebox05W,
                              Text(
                                'Capture',
                                style: UserDetailStyles
                                    .TextStyle_UserDetailsSetProfilePic,
                              )
                            ],
                          ),
                        )),
                    Styles.sizebox10W,
                    Expanded(
                        flex: 1,
                        child: Container(
                          decoration: BoxDecoration(
                              color: AppColors.GREY.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(5)),
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.attach_file_outlined,
                                color: AppColors.PRIMARY_BLACK,
                              ),
                              Styles.sizebox05W,
                              Text(
                                'Attach',
                                style: UserDetailStyles
                                    .TextStyle_UserDetailsSetProfilePic,
                              )
                            ],
                          ),
                        )),
                  ],
                ),
                Styles.sizebox10,
              ],
            ),
          ),
        );
      },
    );
  }
}
