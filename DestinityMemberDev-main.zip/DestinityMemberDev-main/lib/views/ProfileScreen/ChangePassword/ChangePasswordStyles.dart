import 'package:destinity_member_dev/configs/common_Exports.dart';

class ChangePasswordStyles
 {


   static  BoxDecoration inputFieldsContainder = BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppColors.PRIMARY_BLACK));
        static TextStyle TextStyle_InputTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_GREY);
  static TextStyle TextStyle_PasswordPolicy = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      color: AppColors.PRIMARY_BLACK);
  static TextStyle TextStyle_PasswordPolicyItem = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      fontSize: Styles.FONT_SIZE_12,
      color: AppColors.PRIMARY_GREY);
      
  static BoxDecoration boxDecorationProfileImg = BoxDecoration(
      shape: BoxShape.circle,
      color: AppColors.PRIMARY_GREY_LARK,
      boxShadow: [Styles.boxShadow],
      border: Border.all(color: AppColors.WHITE, width: 2));


  static TextStyle TextStyle_UserDetailsDate = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_12);
  static TextStyle TextStyle_UserDetailsSetProfilePic = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.REGULAR,
      color: AppColors.PRIMARY_BLACK,
      fontSize: Styles.FONT_SIZE_14);

}
