import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/ProfileScreen/ChangePassword/ChangePasswordStyles.dart';
import 'package:destinity_member_dev/widgets/CommonAlert.dart';
import 'package:flutter/cupertino.dart';

import '../../../widgets/CommonLoading.dart';
import '../../../widgets/CustomButton.dart';
import '../../../widgets/InputField.dart';

class Changepassword extends StatefulWidget {
  const Changepassword({super.key});

  @override
  State<Changepassword> createState() => _ChangepasswordState();
}

class _ChangepasswordState extends State<Changepassword> {
  TextEditingController ctrCurrentPassword = TextEditingController();
  TextEditingController ctrNewPassword = TextEditingController();
  TextEditingController ctrRetypeNewPassword = TextEditingController();

  FocusNode focusNodeCtrCurrentPassword = FocusNode();
  FocusNode focusNodectrNewPassword = FocusNode();
  FocusNode focusNodectrRetypeNewPassword = FocusNode();

  void _ChangePassword(context) {
    if (ctrCurrentPassword.text.isEmpty ||
        ctrNewPassword.text.isEmpty ||
        ctrRetypeNewPassword.text.isEmpty) {
      ctrCurrentPassword.text.isEmpty
          ? showAlertDialog(context, ' Please Enter Current Password !')
          : ctrNewPassword.text.isEmpty
              ? showAlertDialog(context, 'Please Enter New Password !')
              : ctrRetypeNewPassword.text.isEmpty
                  ? showAlertDialog(context, 'Please confirm New Password !')
                  : showAlertDialog(context, 'Can not keep empty fields!');
    } else if (ctrCurrentPassword.text == ctrNewPassword.text) {
      setState(() {
        ctrNewPassword.clear();
        ctrRetypeNewPassword.clear();
      });
      showAlertDialog(context, 'Same Current Password & New Password');
    } else if (ctrNewPassword.text != ctrRetypeNewPassword.text) {
      setState(() {
        ctrNewPassword.clear();
        ctrRetypeNewPassword.clear();
      });

      showAlertDialog(
          context, 'New password and Confirm Password does not match');
    } else {
      showLoading(context, 'Submitting..');
      Future.delayed(Duration(seconds: 3), () {
        hideLoading(context);

        showAlertDialog(context, 'Sucessfully Changed the passwod',
            title: 'Sucessful', alertType: 2, onPressNegativeBtn: () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
        });
        //Navigator.pop(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Change Password', []),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 20),
                margin: EdgeInsets.only(top: 20),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.password_outlined,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'Current Password',
                            style: ChangePasswordStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField(
                          'Enter Current Password', ctrCurrentPassword,
                          obscureText: true,
                          context: context,
                          CurrentFocusNod: focusNodeCtrCurrentPassword,
                          NextFocusNode: focusNodectrNewPassword),
                      Styles.sizebox20,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'New Password',
                            style: ChangePasswordStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField(
                          '8 Characters or more new password', ctrNewPassword,
                          obscureText: true,
                          context: context,
                          CurrentFocusNod: focusNodectrNewPassword,
                          NextFocusNode: focusNodectrRetypeNewPassword),
                      Styles.sizebox20,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_person_outlined,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'Retype New Password',
                            style: ChangePasswordStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField(
                        'confirm new password',
                        ctrRetypeNewPassword,
                        obscureText: true,
                        context: context,
                        CurrentFocusNod: focusNodectrRetypeNewPassword,
                      ),
                      Styles.sizebox40,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Password Policy',
                                style: ChangePasswordStyles
                                    .TextStyle_PasswordPolicy,
                              ),
                              Styles.sizebox10,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'Minimum of 8 characters',
                                    style: ChangePasswordStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'At least 1 Numeric character',
                                    style: ChangePasswordStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'At least 1 Upper case letter',
                                    style: ChangePasswordStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'At least 1 Lower case letter',
                                    style: ChangePasswordStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'At least 1 Special character',
                                    style: ChangePasswordStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(

              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                      child: CustomButton(
                          fontSize: 14,
                          'Change Password',
                          () => _ChangePassword(context))),
                  Styles.sizebox10W,
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: Colors.blue),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Cancel'),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
