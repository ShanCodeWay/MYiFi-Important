import 'package:destinity_member_dev/configs/common_Exports.dart';

import 'package:destinity_member_dev/widgets/CommonAlert.dart';
import 'package:flutter/cupertino.dart';

import '../../../widgets/CommonLoading.dart';
import '../../../widgets/CustomButton.dart';
import '../../../widgets/InputField.dart';
import 'ChangePinScreenStyles.dart';

class ChangePinScreen extends StatefulWidget {
  const ChangePinScreen({super.key});

  @override
  State<ChangePinScreen> createState() => _ChangePinScreenState();
}

class _ChangePinScreenState extends State<ChangePinScreen> {
  TextEditingController ctrCurrentPassword = TextEditingController();
  TextEditingController ctrNewPassword = TextEditingController();
  TextEditingController ctrRetypeNewPassword = TextEditingController();

  FocusNode focusNodeCtrCurrentPassword = FocusNode();
  FocusNode focusNodectrNewPassword = FocusNode();
  FocusNode focusNodectrRetypeNewPassword = FocusNode();

  void _ChangePin(context) {
    if (ctrCurrentPassword.text.isEmpty ||
        ctrNewPassword.text.isEmpty ||
        ctrRetypeNewPassword.text.isEmpty) {
      ctrCurrentPassword.text.isEmpty
          ? showAlertDialog(context, ' Please Enter Current Password !')
          : ctrNewPassword.text.isEmpty
              ? showAlertDialog(context, 'Please Enter New Password !')
              : ctrRetypeNewPassword.text.isEmpty
                  ? showAlertDialog(context, 'Please confirm New Password !')
                  : showAlertDialog(context, 'Can not keep empty fields!');
    } else if (ctrCurrentPassword.text == ctrNewPassword.text) {
      setState(() {
        ctrNewPassword.clear();
        ctrRetypeNewPassword.clear();
      });
      showAlertDialog(context, 'Same Current Password & New Password');
    } else if (ctrNewPassword.text != ctrRetypeNewPassword.text) {
      setState(() {
        ctrNewPassword.clear();
        ctrRetypeNewPassword.clear();
      });

      showAlertDialog(
          context, 'New password and Confirm Password does not match');
    } else {
      showLoading(context, 'Submitting..');
      Future.delayed(Duration(seconds: 3), () {
        hideLoading(context);

        showAlertDialog(context, 'Sucessfully Changed the passwod',
            title: 'Sucessful', alertType: 2, onPressNegativeBtn: () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
        });
        //Navigator.pop(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppbar(context, 'Change Pin', []),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 20),
                margin: EdgeInsets.only(top: 20),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.password_outlined,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'Current Pin',
                            style: ChangePinScreenStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField(
                          'Enter Current Pin', ctrCurrentPassword,
                          obscureText: true,
                          keyBoardType: 2,
                          context: context,
                          CurrentFocusNod: focusNodeCtrCurrentPassword,
                          NextFocusNode: focusNodectrNewPassword),
                      Styles.sizebox20,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'New Pin',
                            style: ChangePinScreenStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField('4 Characters Pin', ctrNewPassword,
                          obscureText: true,
                          keyBoardType: 2,
                          context: context,
                          CurrentFocusNod: focusNodectrNewPassword,
                          NextFocusNode: focusNodectrRetypeNewPassword),
                      Styles.sizebox20,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.lock_person_outlined,
                            size: 22,
                            color: AppColors.PRIMARY_GREY,
                          ),
                          Styles.sizebox10W,
                          Text(
                            'ReEnter New Pin',
                            style: ChangePinScreenStyles.TextStyle_InputTitle,
                          ),
                        ],
                      ),
                      Styles.sizebox05,
                      CustomTextInputField(
                        'confirm new Pin',
                        ctrRetypeNewPassword,
                        obscureText: true,
                        keyBoardType: 2,
                        context: context,
                        CurrentFocusNod: focusNodectrRetypeNewPassword,
                      ),
                      Styles.sizebox40,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Pin Policy',
                                style: ChangePinScreenStyles
                                    .TextStyle_PasswordPolicy,
                              ),
                              Styles.sizebox10,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'Maximum of 4 characters',
                                    style: ChangePinScreenStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                              Row(
                                children: [
                                  Icon(
                                    Icons.circle,
                                    size: 10,
                                    color: AppColors.PRIMARY_GREY_LARK,
                                  ),
                                  Styles.sizebox10W,
                                  Text(
                                    'Allowed only Numbers',
                                    style: ChangePinScreenStyles
                                        .TextStyle_PasswordPolicyItem,
                                  ),
                                ],
                              ),
                              Styles.sizebox05,
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                      child: CustomButton(
                          fontSize: 14,
                          'Change Password',
                          () => _ChangePin(context))),
                  Styles.sizebox10W,
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppColors.PRIMARY_BLUE),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Cancel'),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
