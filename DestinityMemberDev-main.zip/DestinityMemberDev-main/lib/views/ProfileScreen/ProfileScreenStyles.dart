import '../../configs/common_Exports.dart';

class ProfileScreenStyles {
  static BoxDecoration boxDecorationSettingsItem = BoxDecoration(
      color: AppColors.WHITE,
      borderRadius: BorderRadius.circular(10),
      boxShadow: [Styles.boxShadow]);

  static BoxDecoration boxDecorationProfileImg = BoxDecoration(
      shape: BoxShape.circle,
      color: AppColors.PRIMARY_GREY_LARK,
      boxShadow: [Styles.boxShadow],
      border: Border.all(color: AppColors.WHITE, width: 2));

  static BoxDecoration ProfileOuter = BoxDecoration(
      gradient: ProfileGradient,
      border: Border.all(color: AppColors.WHITE, width: 1),
      borderRadius: BorderRadius.circular(10));

  static LinearGradient ProfileGradient = LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        AppColors.PRIMARY_BLUE,
        AppColors.PRIMARY_BLUE.withOpacity(0.7),
      ]);


  static TextStyle TextStyleSettingsName = TextStyle(
    color: AppColors.PRIMARY_BLACK,
    fontSize: 15,
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );
  static TextStyle TextStyleGreeting = TextStyle(
    color: AppColors.WHITE,
    fontSize: Styles.FONT_SIZE_14,
    fontFamily: 'Poppins',
    fontWeight: Styles.REGULAR,
  );
  static TextStyle TextStyleSettingsDescription = TextStyle(
    color: AppColors.PRIMARY_GREY,
    fontSize: Styles.FONT_SIZE_10,
    fontFamily: 'Inter',
  );
  static TextStyle TextStyleDetails = TextStyle(
    color: AppColors.WHITE,
    fontSize: Styles.FONT_SIZE_12,
    fontFamily: 'Inter',
  );
    static TextStyle TextStyleValidDate = TextStyle(
    color: AppColors.PRIMARY_RED,
    fontSize: Styles.FONT_SIZE_10,
    fontFamily: 'Inter',
fontWeight: Styles.SEMI_BOLD

  );
}
