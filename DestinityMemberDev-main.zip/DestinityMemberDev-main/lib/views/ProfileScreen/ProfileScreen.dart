import 'package:destinity_member_dev/configs/common_Exports.dart';
import 'package:destinity_member_dev/views/ProfileScreen/ChangePassword/ChangePassword.dart';
import 'package:destinity_member_dev/views/ProfileScreen/ChangePin/ChangePinScreen.dart';
import 'package:destinity_member_dev/views/ProfileScreen/UserDetailsScreen/UserDetailsScreen.dart';
import 'package:destinity_member_dev/widgets/CustomButton.dart';
import 'package:flutter/material.dart';

import '../../widgets/CommonAlert.dart';
import 'ProfileScreenStyles.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {



  backPress() {
    showAlertDialog(context, 'Do you want to Logout ?',
        title: 'Logout', isPositiveBtnVisible: true, onPressPositiveBtn: () {
      Navigator.of(context).pop(); // Close the AlertDialog
      Navigator.of(context).pop(); // Navifate to Login
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.all(20),
                decoration: ProfileScreenStyles.ProfileOuter,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  
                  children: [
                    Container(
                        width: 100,
                        height: 100,
                        decoration: ProfileScreenStyles.boxDecorationProfileImg,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(100),
                          child: Image.asset(
                            'assets/images/img_ProfilePic.png',
                            fit: BoxFit.cover,
                          ),
                        )),
                    Styles.sizebox20W,
                    Container(
                    
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hello Prageeth !',
                            style: ProfileScreenStyles.TextStyleGreeting,
                          ),
                          Styles.sizebox10,
                          Text(
                            'Last Login: ${DateTime.now().year}-${DateTime.now().month}-${DateTime.now().day}',
                            style: ProfileScreenStyles.TextStyleDetails,
                          ),
                          Styles.sizebox05,
                  
                          Styles.sizebox05,
                          CustomButton(
                            'SignOut',
                            () => backPress(),
                            btnRadius: 50,
                            btnWidth: 120,
                            btnHeight: 40,
                            fontSize: 14,
                            btnColor: AppColors.PRIMARY_RED,
                          ),
                  
                        ],
                      ),
                    )
                  ],
                ),
              ),
    
              ProfileItem('User Details', 'Change your personal details',
                  Icons.person_rounded, () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserDetailsScreen()),
                );
              }),
              ProfileItem('Change Password', 'Change  your Current password',
                  Icons.password_rounded, () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Changepassword()),
                );
              }),
              ProfileItem('Change Pin', 'Change  your  Current pin',
                  Icons.pin_rounded,
                  () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChangePinScreen()),
                );
              }),
              ProfileItem('Settings', 'Dark Mode , permissons', Icons.settings,
                  () => null),
              Styles.sizebox20,
          
            ],
          ),
        ),
         
      ),
    );
  }
}

Widget ProfileItem(
    String title, String subTitle, IconData leadingIcon, Function() onPress) {
  return InkWell(
    onTap: onPress,
    child: Container(
      height: 80,
      margin: const EdgeInsets.only(left: 12, right: 12, top: 10),
      padding: const EdgeInsets.all(20),
      decoration: ProfileScreenStyles.boxDecorationSettingsItem,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            leadingIcon,
            size: 30,
            color: AppColors.PRIMARY_GREY,
          ),
          const SizedBox(
            width: 20,
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: ProfileScreenStyles.TextStyleSettingsName,
              ),
              SizedBox(
                width: 200,
                child: Text(
                  subTitle,
                  style: ProfileScreenStyles.TextStyleSettingsDescription,
                ),
              ),
            ],
          ),
          Expanded(
            child: Align(
              alignment: Alignment.centerRight,
              child: Icon(
                Icons.navigate_next_rounded,
                color: AppColors.PRIMARY_GREY_LARK,
              ),
            ),
          )
        ],
      ),
    ),
  );
}
