// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';

import '../../styles/AppColors.dart';
import '../../styles/CommonStyles.dart';

class LoginScreenStyles {
  static BoxDecoration BoxDecoration_MiddleContainer = BoxDecoration(
      color: AppColors.WHITE.withOpacity(0.6),
      borderRadius: const BorderRadius.all(Radius.circular(20)),
      border: Border.all(width: 1.5, color: AppColors.WHITE.withOpacity(1)));

  static TextStyle TextStyle_InputTitle = TextStyle(
      fontFamily: 'Poppins',
      fontWeight: Styles.MEDIUM,
      fontSize: Styles.FONT_SIZE_12,
      color: AppColors.PRIMARY_GREY);
  static TextStyle TextStyle_ForgotPassword = TextStyle(
      fontFamily: 'Poppins',
      letterSpacing: 0.0,
      fontSize: Styles.FONT_SIZE_10 ,
      fontWeight: Styles.SEMI_BOLD,
      color: AppColors.PRIMARY_BLUE);
  static TextStyle TextStyle_Footer = TextStyle(
      fontFamily: 'Poppins',
      letterSpacing: 0.0,
      fontSize: Styles.FONT_SIZE_12,
      fontWeight: Styles.LIGHT,
      color: AppColors.PRIMARY_BLACK);
}
