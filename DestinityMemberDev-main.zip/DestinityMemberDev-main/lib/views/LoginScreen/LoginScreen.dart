import 'dart:async';

import 'package:destinity_member_dev/styles/AppColors.dart';
import 'package:destinity_member_dev/views/LoginScreen/LoginScreenStyles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../styles/CommonStyles.dart';
import '../../widgets/CommonAlert.dart';
import '../../widgets/CommonLoading.dart';
import '../../widgets/CustomButton.dart';
import '../../widgets/InputField.dart';
import '../Dashboard/DashboardScreen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController ctrUserName = TextEditingController();
  TextEditingController ctrPassword = TextEditingController();
  FocusNode focusNodeUserName = FocusNode();
  FocusNode focusNodePassword = FocusNode();

  

  void onPressLogin() {
    if (ctrUserName.text.isEmpty) {
      showAlertDialog(context, 'Please Enter the Username');
    } else if (ctrPassword.text.isEmpty) {
      showAlertDialog(context, 'Please Enter the Password');
    } else {
      showLoading(context, 'Checking User..');
      setState(() {
        ctrUserName.clear();
        ctrPassword.clear();
      });
      //Delay and navigate
      Timer(Duration(seconds: 3), () {
        hideLoading(context);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DashboardScreen()),
        );
      });
    }
  }

  bool popScope() {
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: popScope(),
      child: Scaffold(
        body: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          return SafeArea(
              child: Center(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                gradient: Styles.ScreenGradient,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [


                  Expanded(
                    child: Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 120,
                        height: 120,
                        child: Image.asset(
                          'assets/images/logo_ic_club.png',
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: constraints.maxWidth > 600
                        ? constraints.maxWidth * 0.2
                        : constraints.maxWidth,
                    margin: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                    decoration: LoginScreenStyles.BoxDecoration_MiddleContainer,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,

                          children: [
                            Text(
                              'Login',
                              style: Styles.TextStyle_Header,
                            )
                          ],
                        ),
                        Styles.sizebox10,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [


                            Icon(
                              Icons.person_outline_outlined,
                              size: 22,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text(
                              'User Name',
                              style: LoginScreenStyles.TextStyle_InputTitle,
                            ),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Username', ctrUserName,
                            context: context,
                            CurrentFocusNod: focusNodeUserName,
                            NextFocusNode: focusNodePassword),
                        Styles.sizebox10,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.lock_outline_sharp,
                              size: 20,
                              color: AppColors.PRIMARY_GREY,
                            ),
                            Text('Password',
                                style: LoginScreenStyles.TextStyle_InputTitle),
                          ],
                        ),
                        Styles.sizebox05,
                        CustomTextInputField('Enter Password', ctrPassword,
                            obscureText: true,
                            context: context,
                            CurrentFocusNod: focusNodePassword),
                        Styles.sizebox05,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                                onPressed: () => null,
                                child: Text(
                                  'Forgot  Password'.toUpperCase(),
                                  style: LoginScreenStyles
                                      .TextStyle_ForgotPassword,
                                ))
                          ],
                        ),
                        Styles.sizebox10,
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Expanded(
                              child: CustomButton('LOGIN', () => onPressLogin(),
                                  btnHeight: 40),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Align(
                      heightFactor: 1,
                      alignment: Alignment.bottomCenter,
                      child: Text(
                        '©2023 - Member Portal by scienter',
                        style: LoginScreenStyles.TextStyle_Footer,
                      ),
                    ),
                  ),
          
          
                ],
              ),
            ),
          ));
        }),
      ),
    );
  }
}


// import 'dart:async';

// import 'package:destinity_member_dev/styles/AppColors.dart';
// import 'package:destinity_member_dev/views/LoginScreen/LoginScreenStyles.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';

// import '../../styles/CommonStyles.dart';
// import '../../widgets/CommonAlert.dart';
// import '../../widgets/CommonLoading.dart';
// import '../../widgets/CustomButton.dart';
// import '../../widgets/InputField.dart';
// import '../Dashboard/DashboardScreen.dart';

// class LoginScreen extends StatefulWidget {
//   const LoginScreen({super.key});

//   @override
//   State<LoginScreen> createState() => _LoginScreenState();
// }

// class _LoginScreenState extends State<LoginScreen> {
//   TextEditingController ctrUserName = TextEditingController();
//   TextEditingController ctrPassword = TextEditingController();

//   void onPressLogin() {
//     if (ctrUserName.text.isEmpty) {
//       showAlertDialog(context, 'Please Enter the Username');
//     } else if (ctrPassword.text.isEmpty) {
//       showAlertDialog(context, 'Please Enter the Password');
//     } else {
//       showLoading(context, 'Checking User..');
//       setState(() {
//         ctrUserName.clear();
//         ctrPassword.clear();
//       });
//       //Delay and navigate
//       Timer(Duration(seconds: 3), () {
//         hideLoading(context);
//         Navigator.push(
//           context,
//           MaterialPageRoute(builder: (context) => DashboardScreen()),
//         );
//       });
//     }
//   }

//   bool popScope() {
//     return false;
//   }

//   @override
//   Widget build(BuildContext context) {
//     return PopScope(
//       canPop: popScope(),
//       child: Scaffold(
//         body: SafeArea(
//             child: Center(
//           child: Container(
//             width: double.infinity,
//             height: double.infinity,
//             decoration: BoxDecoration(
//               gradient: Styles.ScreenGradient,
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Expanded(
//                   child: Align(
//                     alignment: Alignment.center,
//                     child: SizedBox(
//                       width: 120,
//                       height: 120,
//                       child: Image.asset(
//                         'assets/images/logo_ic_club.png',
//                       ),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   margin: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
//                   padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
//                   width: double.infinity,
//                   decoration: LoginScreenStyles.BoxDecoration_MiddleContainer,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisSize: MainAxisSize.min,
//                     children: [
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           Text(
//                             'Login',
//                             style: Styles.TextStyle_Header,
//                           )
//                         ],
//                       ),
//                       Styles.sizebox10,
//                       Row(
//                         children: [
//                           SizedBox(
//                             width: 20,
//                             height: 20,
//                             child: SvgPicture.asset(
//                                 'assets/icons/icon_username.svg',
//                                 semanticsLabel: 'Acme Logo'),
//                           ),
//                           Text(
//                             'User Name',
//                             style: LoginScreenStyles.TextStyle_InputTitle,
//                           ),
//                         ],
//                       ),
//                       Styles.sizebox05,
//                       CustomTextInputField('Enter Username', ctrUserName),
//                       Styles.sizebox10,
//                       Row(
//                         children: [
//                           SvgPicture.asset('assets/icons/icon_password.svg',
//                               semanticsLabel: 'Acme Logo'),
//                           Text('Password',
//                               style: LoginScreenStyles.TextStyle_InputTitle),
//                         ],
//                       ),
//                       Styles.sizebox05,
//                       CustomTextInputField('Enter Password', ctrPassword,
//                           obscureText: true),
//                       Styles.sizebox05,
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           TextButton(
//                               onPressed: () => null,
//                               child: Text(
//                                 'Forgot  Password'.toUpperCase(),
//                                 style:
//                                     LoginScreenStyles.TextStyle_ForgotPassword,
//                               ))
//                         ],
//                       ),
//                       Styles.sizebox10,
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           Expanded(
//                             child: CustomButton('LOGIN', () => onPressLogin(),
//                                 btnHeight: 40),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 Expanded(
//                   child: Align(
//                     heightFactor: 1,
//                     alignment: Alignment.bottomCenter,
//                     child: Text(
//                       '©2023 - Member Portal by scienter',
//                       style: LoginScreenStyles.TextStyle_Footer,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         )),
//       ),
//     );
//   }
// }
