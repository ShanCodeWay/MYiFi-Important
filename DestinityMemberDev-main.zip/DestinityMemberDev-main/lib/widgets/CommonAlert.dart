
  // Function to show the AlertDialog
  import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';

import '../configs/common_Exports.dart';

Future<void> showAlertDialog(
  BuildContext context,
  String msg, {
  int alertType = 1,
  String title = 'Error',
  bool isPositiveBtnVisible = false,
  Function()? onPressPositiveBtn,
  Function()? onPressNegativeBtn,
}) async {


  
  return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return CupertinoAlertDialog(
        title: Text(title),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
              
              alertType == 1
                  ? SizedBox()
                  : alertType == 2
                      ? Lottie.asset(
                          fit: BoxFit.contain,
                          height: 200,
                          repeat: false,
                          alignment: Alignment.center,
                          width: 200,
                          'assets/lotties/lottie_done.json')
                      : SizedBox(),
              
              Text(msg),
              
              ],
            ),
          ),
          
          
        actions: isPositiveBtnVisible
            ? <Widget>[
                TextButton(child: Text('Yes'), onPressed: onPressPositiveBtn),
                TextButton(
                  child: Text('No'),
                  onPressed: () {
                    Navigator.of(context).pop(); // Close the AlertDialog
                  },
                ),
              ]
            : <Widget>[
                TextButton(
                  child: Text('OK'),

                  
                  onPressed: onPressNegativeBtn ??
                      () {
                        Navigator.of(context).pop(); // Close the AlertDialog
                      },
                ),


              ], 
        );
      },
    );



  }
