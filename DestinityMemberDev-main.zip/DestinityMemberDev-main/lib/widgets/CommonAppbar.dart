import 'package:destinity_member_dev/configs/common_Exports.dart';

PreferredSizeWidget CommonAppbar(context, String Title, List<Widget> actions) {
  return AppBar(
    backgroundColor: AppColors.PRIMARY_BLUE,
    leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(
          Icons.navigate_before_sharp,
          color: AppColors.WHITE,
          size: 30,
        )),
    title: Text(Title,
        style:
            TextStyle(color: AppColors.WHITE, fontSize: Styles.FONT_SIZE_20)),
    actions: [],
  );
}
