import '../configs/common_Exports.dart';

Widget CommonDropDown(IconData icon, dropdownValue, list, onChange(value),
    {Width = 150.00}) {
  return Container(
    decoration: BoxDecoration(
        border: Border.all(color: AppColors.PRIMARY_BLUE, width: 1),
        borderRadius: BorderRadius.circular(10)),
    child: DropdownButton<String>(
      
      value: dropdownValue,
      elevation: 16,
      isExpanded: true,
      padding: EdgeInsets.symmetric(horizontal: 20),
      style: TextStyle(
          color: AppColors.PRIMARY_BLACK, fontSize: Styles.FONT_SIZE_16),
      underline: Container(
        height: 2,
        color: AppColors.TRANSPARENT,
      ),
      onChanged: (String? value) {
        // This is called when the user selects an item.
        onChange(value);
      },
      items: list.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    ),
  );

  //  DropdownMenu<String>(
  //   width: Width,
  //   leadingIcon: Icon(icon),
  //   initialSelection: list.first,
  //   onSelected: (String? value) {
  //     onChange(value);
  //   },
  //   dropdownMenuEntries: list.map<DropdownMenuEntry<String>>((String value) {
  //     return DropdownMenuEntry<String>(
  //       value: value,
  //       label: value,
  //     );
  //   }).toList(),
  // );
}
