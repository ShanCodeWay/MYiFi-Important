// Function to show the AlertDialog
import 'package:flutter/cupertino.dart';

import '../configs/common_Exports.dart';

Future<void> showLoading(BuildContext context, String msg) async {
  return showDialog<void>(
    context: context,
    
    builder: (BuildContext context) {
      return Center(
        child: Container(
          child: CupertinoAlertDialog(
            content: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Styles.circularProgressAndroid,
                  Styles.sizebox30W,
                  Text(
                    msg,
                    style: Styles.TextStyle_Description,
                  ),
                ],
              ),
            ),
            actions: [],
          ),
        ),
      );
    },
  );
}

hideLoading(context) {
  Navigator.of(context).pop();
}
