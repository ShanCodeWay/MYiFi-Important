// ignore_for_file: file_names, non_constant_identifier_names, prefer_const_constructors

import 'package:destinity_member_dev/styles/CommonStyles.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../styles/AppColors.dart';

Widget CustomTextInputField(String labelTitle, TextEditingController Controller,
    {double fontSize = 12.0,
    int maxLines = 1,
    bool obscureText = false,
    int keyBoardType = 1,
    context,
    height = 50.00,
    FocusNode? CurrentFocusNod,
    FocusNode? NextFocusNode}) {
  return SizedBox(
    height: height,
    child: TextField(
      
      obscureText: obscureText,
      maxLines: maxLines,
      textAlignVertical: TextAlignVertical.bottom,
      textAlign: TextAlign.start,
      controller: Controller,
      focusNode: CurrentFocusNod,
      keyboardType:
          keyBoardType == 1 ? TextInputType.text : TextInputType.number,
      onSubmitted: (value) {
        if (NextFocusNode != null) {
          FocusScope.of(context).requestFocus(NextFocusNode);

        }
       
      },
      decoration: InputDecoration(
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: AppColors.PRIMARY_BLUE, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: AppColors.PRIMARY_BLUE),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: AppColors.WHITE),
          ),
          hintText: labelTitle,
          hintStyle: TextStyle(
              fontSize: fontSize,
              fontFamily: 'Poppins',
              color: AppColors.PRIMARY_GREY,
              fontWeight: Styles.REGULAR,
              fontStyle: FontStyle.italic),
          filled: true,
          fillColor: AppColors.WHITE.withOpacity(0.6)),
      style: TextStyle(
        fontSize: fontSize,
        fontFamily: 'Poppins',
        color: AppColors.BLACK,
        fontStyle: FontStyle.normal,
      ),
    ),
  );
}
