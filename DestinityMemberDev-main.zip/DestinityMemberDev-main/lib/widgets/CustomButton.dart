// ignore_for_file: non_constant_identifier_names

import '../configs/common_Exports.dart';

Widget CustomButton(String title, Function() onPressed,
    {double btnWidth = 200.0,
    double btnHeight = 45.0,
    double fontSize = 16.0,
    Color? fontColor ,
    double btnRadius = 10.0,
    Color? btnColor ,
  IconData? btnIcon,
  Color? iconColor,
}) {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(btnRadius),
      color:btnColor ?? AppColors.PRIMARY_BLUE
    ),
    width: btnWidth,
    height: btnHeight,
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        shadowColor: AppColors.TRANSPARENT,
        backgroundColor: AppColors.TRANSPARENT,
        textStyle:  TextStyle(fontWeight: Styles.MEDIUM),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: TextStyle(
              color: fontColor ??  AppColors.WHITE,
              fontSize: fontSize,
              fontFamily: 'Poppins',
            ),
          ),
          Visibility(
              visible: btnIcon != null,
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: Icon(
                  btnIcon,
                  color: iconColor,
                ),
              ))
        ],
      ),
    ),
  );
}

//Custom Button Styles
LinearGradient btnGradient = LinearGradient(colors: [
  AppColors.PRIMARY_BLUE,
  AppColors.PRIMARY_BLUE.withOpacity(0.7),
  AppColors.PRIMARY_BLUE.withOpacity(0.3),
]);
