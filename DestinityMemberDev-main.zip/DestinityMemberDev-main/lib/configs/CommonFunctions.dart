//Dinuranga - 22/12/08 -  Table cross axisCount
import 'package:destinity_member_dev/configs/common_Exports.dart';

getCrossAxisCount(BuildContext context) {
  int width = MediaQuery.of(context).size.width.round();
  print(width);
  if (width < 500) {
    return 2;
  } else if (width >= 500 && width < 700) {
    return 3;
  } else if (width >= 700 && width < 900) {
    return 4;
  } else if (width >= 900) {
    return 5;
  }
}