package com.example.destinity_member_dev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
